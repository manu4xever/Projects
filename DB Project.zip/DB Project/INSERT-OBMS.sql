------------------------------Script to insert the sample data to all tables----------------------------------
Customer Table:-

Insert into Customer values('david@gmail.com','david123','david@123','11-MAR-1999', 'M','david','beckham','E.border','arlington','TX',76010);
Insert into Customer values ('elisa@gmail.com','elisa123','elisa@123','12-MAY-1995', 'F','elisa','ray','Raymond','San Francisco','CA',94016);
Insert into Customer values ('brian@gmail.com','brian123','brian@123','13-AUG-1991', 'M','brian','mike','SouthWest','Chicago','IL',60007);
Insert into Customer values ('tom@gmail.com' ,'tom123','tom@123','14-JAN-1992', 'M','tom','cruise','Blvd','Boston','MA',21100);
Insert into Customer values ('mike@gmail.com','mike123','mike@123', '15-FEB-1993', 'M','mike','jack','Times','New York','NY',10011);
Insert into Customer values ('andy@gmail.com','andy123','andy@123', '16-JUN-1988', 'M','andy','murray','Deon','Miami','FL',33101);
Insert into Customer values ('chris@gmail.com','chris123','chris@123','17-AUG-1966', 'M','chris','nolan','border','Dallas','TX',75019);
Insert into Customer values ('ben@gmail.com', 'ben123', 'ben@123', '18-OCT-1956', 'M','ben','ten','hick','Seattle','WA',98101);
Insert into Customer values ('tuyen@gmail.com','tuyen123','tuyen@123', '19-MAY-1988', 'F','tuyen','lisa','Strip','Las Vegas','CA',88901);
Insert into Customer values ('nathan@gmail.com','nathan123','nathan@123', '20-DEC-1994', 'M','nathan','bryan','Golden Gate','San Francisco','CA',94010);
Insert into Customer values ('kelly@gmail.com','kelly123','kelly@123', '21-MAR-1992', 'F','kelly','ann','Sind','Atlanta','GA',30301);
Insert into Customer values ('ricky@gmail.com','ricky123', 'ricky@123', '1-MAY-1999', 'M','ricky','martin','fight','Denver','CO',80014);
Insert into Customer values ('neil@gmail.com','neil123','neil@123', '1-JAN-1965', 'M','neil','nithin','hirl','Nashville','TN',37011);
Insert into Customer values ('karen@gmail.com','karen123','karen@123','12-MAR-1970', 'F','karen','fisher','werst','Chicago','IL',60010);
Insert into Customer values ('paula@gmail.com','paula123','paula@123','16-JUL-1975', 'F','paula','july','Corner','San Francisco','CA',94106);
Insert into Customer values ('cindy@gmail.com','cindy123','cindy@123','23-AUG-1980', 'F','cindy','minx','Rame Blvd','Boston','MA',21100);
Insert into Customer values ('carl@gmail.com','carl123', 'carl@123','3-AUG-1970', 'M','carl','marx','Chaples','New York','NY',10009);
Insert into Customer values ('johnson12@gmail.com','johnson123', 'johnson@123', '9-MAR-1969', 'M','johnson','michael','Mint','Chicago','IL',60687); 
Insert into Customer values ('michael1@gmail.com','michael123', 'michael@123','12-JAN-1985', 'M','michael','shawn','Justin','Miami','FL',33101);
Insert into Customer values ('selena5@gmail.com','selena123', 'selena@123','8-MAY-1980', 'F','selena','gomez','ron','Dallas','TX',75019);
Insert into Customer values ('peter8@gmail.com','peter123', 'peter@123', '8-JUN-1988', 'M','peter','pan','Main','Las Vegas','CA',88901);
Insert into Customer values ('pat@gmail.com','patrick123', 'patrick@123','10-AUG-1981', 'M','patrick','john','hick','Seattle','WA',98101);
Insert into Customer values ('don@gmail.com','donald123','donald@123','18-AUG-1984', 'M','donald','jones','geary','San Francisco','CA',94112);
Insert into Customer values ('james@gmail.com','james123', 'james@123', '19-MAY-1988', 'M','james','anderson','orland','Denver','CO',80015);
Insert into Customer values ('alisha@gmail.com','alisha123','alisha@123','20-FEB-1982', 'F','alisha','michelle','mesquite','arlington','TX',76019);
Insert into Customer values ('emily@gmail.com','emily123','emily@123','1-FEB-1984', 'F','emily','clark','yerk','Philadelphia','PA',19010);
Insert into Customer values ('aaliyah@gmail.com','aaliyah123','aaliyah@123','6-JAN-1982', 'F','aaliyah','bhatt','gink','Atlanta','GA',30301);
Insert into Customer values ('jennifer@gmail.com','jennifer123','jennifer@123', '20-AUG-1986', 'F','jennifer','aniston','Central Perk','New York','NY',10011);
Insert into Customer values ('olivia@gmail.com', 'olivia123','olivia@123', '6-MAR-1999', 'F','olivia','austin','Lamer','Nashville','TN',37011);
Insert into Customer values ('hannah@gmail.com', 'hannah123','hannah@123', '4-MAY-1970', 'F','hannah','montana','Sideway','Chicago','IL',60626);
Insert into Customer values ('jessica@gmail.com','jessica123','jessica@123', '7-DEC-1985', 'F','jessica','james','East Blvd','Chicago','IL',60611);
Insert into Customer values ('sarah@gmail.com', 'sarah123','sarah@123','10-MAY-1982', 'F','sarah','may','gean','Chicago','IL',60040);
Insert into Customer values ('lily@gmail.com', 'lily123','lily@123','28-FEB-1979', 'F','lily','julie','Long','Las Vegas','CA',88901);
Insert into Customer values ('savannah@gmail.com','savannah123', 'savannah@123', '11-JUL-1982', 'F','savannah','stone','lake','Miami','FL',33101);
Insert into Customer values ('isabella@gmail.com','isabella123','isabella@123','5-AUG-1985', 'F','isabella','mary','Weiner','Austin','TX',78702);
Insert into Customer values ('sophia@gmail.com','sophia123','sophia@123','2-FEB-1987', 'F','sophia','bary','Jone','Nashville','TN',37013);
Insert into Customer values ('ava@gmail.com','ava123','ava@123','2-MAR-1972', 'F','ava','adam','Wints','Houston','TX',77001);
Insert into Customer values ('grace@gmail.com','grace123','grace@123','27-MAY-1985', 'F','grace','annie','Maple','New York','NY',10011);
Insert into Customer values ('Mia@gmail.com','Mia123','Mia@123','14-AUG-1988', 'F','Mia','Doll','kond','Seattle','WA',98101);
Insert into Customer values ('Ella@gmail.com','Ella123','Ella@123','20-MAY-1999', 'F','Ella','rose','Baker','Houston','TX',77001);
Insert into Customer values ('alyssa@gmail.com','alyssa123','alyssa@123', '1-JAN-1995', 'F','alyssa','rose','gran','San Francisco','CA',94112);
Insert into Customer values ('lucy@gmail.com','lucy123', 'lucy@123','31-DEC-1985', 'F','lucy','pinder','garden','Dallas','TX',75010);
Insert into Customer values ('jade@gmail.com','jade123','jade123','29-AUG-1987', 'F','jade','steven','Linx','Atlanta','GA',30301);
Insert into Customer values ('abby@gmail.com','abby123','abby@123','23-FEB-1982', 'F','abby','brrok','lights','Denver','CO',80014);
Insert into Customer values ('kellie@gmail.com', 'kellie123','kellie@123','5-JAN-1982', 'F','kellie','watson','Beach','Miami','FL',33111);
Insert into Customer values ('natalie@gmail.com','natalie123','natalie@123','6-FEB-1985', 'F','natalie','gulbis','Ching Blvd','Chicago','IL',60613);
Insert into Customer values ('amanda@gmail.com', 'amanda123','amanda@123','20-MAY-1988', 'F','amanda','mills','lone','Miami','FL',33101);
Insert into Customer values ('bella@gmail.com','bella123','bella@123','22-FEB-1999', 'F','bella','reese','Onix','New York','NY',10032);
Insert into Customer values ('rachel@gmail.com','rachel123','rachel@123', '5-MAY-1999', 'F','rachel','green','sight','Denver','CO',80014);
Insert into Customer values ('taylor@gmail.com','taylor123','taylor@123','19-FEB-1981', 'F','taylor','swift','Mart','Boston','MA',21150);
Insert into Customer values ('alexis@gmail.com','alexis123','alexis@123', '11-MAY-1995', 'F','alexis','ford','N.Cooper','arlington','TX',76010);
Insert into Customer values ('paige@gmail.com','paige123', 'paige@123', '14-FEB-1982', 'F','paige','rose','Sean','Chicago','IL',60045);
Insert into Customer values ('jacob@gmail.com','Jacob123', 'Jacob@123', '6-JUL-1982', 'M','Jacob','John','Jeremy','San Francisco','CA',94102);
Insert into Customer values ('Shawn@gmail.com','Shawn123', 'Shawn@123','7-MAY-1982', 'M','Shawn','Shape','west','Nashville','TN',37013);
Insert into Customer values ('Muhammad@gmail.com','Muhammad123', 'Muhammad@123','9-AUG-1985', 'M','Muhammad','Nazar','S.Cooper','arlington','TX',76010);
Insert into Customer values ('Aaron@gmail.com','Aaron123', 'Aaron@123','6-MAR-1982', 'M','Aaron','finch','Univ','Philadelphia','PA',19019);
Insert into Customer values ('Daniel@gmail.com', 'Daniel123', 'Daniel@123','8-JUN-1982', 'M','Daniel','robin','Ray','Los Angeles','CA',90001);
Insert into Customer values ('Alex@gmail.com','Alex123', 'Alex@123', '3-MAY-1982', 'M','Alex','john','S.Cooper','arlington','TX',76010);
Insert into Customer values ('Jonah@gmail.com', 'Jonah123', 'Jonah@123','6-DEC-1988', 'M','Jonah','bren','Ranch','Boston','MA',21100);
Insert into Customer values ('Michael@gmail.com','Michael123', 'Michael@123', '8-MAR-1982', 'M','Michael','shen','yale','Los Angeles','CA',90001);
Insert into Customer values ('James@gmail.com','James123','James@123', '9-MAY-1988', 'M','James','chris','prague','Denver','CO',80014);
Insert into Customer values ('Ryan@gmail.com','Ryan123','Ryan@123', '20-JUN-1991', 'M','Ryan','Ronald','Times Square','New York','NY',10021);
Insert into Customer values ('Liam@gmail.com','Liam123','Liam@123', '2-AUG-1982', 'M','Liam','Neeson','Sorn','Chicago','IL',60067);
Insert into Customer values ('David@gmail.com','David123','David@123','1-FEB-1982', 'M','David','Levin','anis','Los Angeles','CA',90001);
Insert into Customer values ('Mathew@gmail.com','Mathew123', 'Mathew@123', '5-MAY-1982', 'M','Mathew','Hayden','N.Mesquite','arlington','TX',76010);
Insert into Customer values ('Jack@gmail.com','Jack123','Jack@123', '7-JUN-1982', 'M','Jack','sock','Pind','Los Angeles','CA',90001);
Insert into Customer values ('Ethan@gmail.com','Ethan123','Ethan@123','9-AUG-1982', 'M','Ethan','Hunt','Waker','San Francisco','CA',94104);
Insert into Customer values ('Luke@gmail.com','Luke123','Luke@123','3-AUG-1982', 'M','Luke','wang','Ray','Los Angeles','CA',90009);
Insert into Customer values ('Jordan@gmail.com','Jordan123','Jordan@123','5-MAY-1982', 'M','Jordan','Mike','Link','Los Angeles','CA',90001);
Insert into Customer values ('Harry@gmail.com', 'Harry123','Harry@123','2-DEC-1982', 'M','Harry','Lane','Mayer','Philadelphia','PA',19019);
Insert into Customer values ('Alexander@gmail.com','Alexander123','Alexander@123','6-FEB-1982', 'M','Alexander','bell','Kily','Los Angeles','CA',90001);
Insert into Customer values ('Ali@gmail.com','Ali123','Ali@123', '11-MAR-1981', 'M','Ali','sharif','Raint','Chicago','IL',60051);
Insert into Customer values ('Tyler@gmail.com','Tyler123','Tyler@123','22-MAR-1983', 'M','Tyler','marn','Mith','Boston','MA',21100);
Insert into Customer values ('Kevin@gmail.com','Kevin123','Kevin@123','17-JAN-1987', 'M','Kevin','peter','Cooper','Boston','MA',21100);
Insert into Customer values ('Joshua@gmail.com','Joshua123','Joshua@123', '3-AUG-1984', 'M','joshua','adam','onete','Dallas','TX',75019);
Insert into Customer values ('Dylan@gmail.com','Dylan123','Dylan@123','1-FEB-1985', 'M','Dylan','Rider','pin','Houston','TX',77001);
Insert into Customer values ('Blake@gmail.com','Blake123','Blake@123','5-AUG-1986', 'M','Blake','John','James','Miami','FL',33102);
Insert into Customer values ('Andrew@gmail.com','Andrew123','Andrew@123', '8-MAY-1982', 'M','Andrew','Tye','UTD','Dallas','TX',75019);
Insert into Customer values ('Zayn@gmail.com','Zayn123','Zayn@123','4-DEC-1999', 'M','Zayn','David','ivery','Olympia','WA',98502);
Insert into Customer values ('Christopher@gmail.com','Christopher123','Christopher@123', '22-AUG-1985', 'M','Christopher','Night','Jay','Los Angeles','CA',90001);
Insert into Customer values ('Johnnn@gmail.com','John123','John@123', '14-AUG-1984', 'M','John','Leger','Chinatown','San Francisco','CA',94109);
Insert into Customer values ('Adam@gmail.com','Adam123','Adam@123', '6-DEC-1987', 'M','Adam','Levine','hons','Knoxville','TN',37087);
Insert into Customer values ('Noah@gmail.com','Noah123','Noah@123','8-JAN-1988', 'M','Noah','Bill','grin','Philadelphia','PA',19019);
Insert into Customer values ('William@gmail.com','William123','William@123', '9-MAR-1984', 'M','William','Mason','Birng','Austin','TX',78702);
Insert into Customer values ('Aiden@gmail.com','Aiden123','Aiden@123', '11-MAR-1985', 'M','Aiden','mills','Anarchy','Austin','TX',78702);
Insert into Customer values ('Spencer@gmail.com','Spencer123','Spencer@123','17-JUN-1982', 'M','Spencer','Shawn','Shane','Chicago','IL',60615);
Insert into Customer values ('Nathan@gmail.com','Nathan123','Nathan@123' ,'11-JUL-1982', 'M','Nathan','Lyon','Collins','San Francisco','CA',94105);
Insert into Customer values ('Niall@gmail.com', 'Niall123','Niall@123','7-AUG-1999', 'M','Niall','Horan','Coll','Boston','MA',21100);
Insert into Customer values ('Logan@gmail.com','Logan123','Logan@123', '8-MAR-1985', 'M','Logan','Hulk','Angle','Austin','TX',78702);
Insert into Customer values ('Jason@gmail.com','Jason123','Jason@123','21-MAR-1987', 'M','Jason','Mayer','Lever','New York','NY',10032);
Insert into Customer values ('Robert@gmail.com','Robert123','Robert@123','19-MAY-1988', 'M','Robert','Junior','Hind','Atlanta','GA',30305);
Insert into Customer values ('Austin@gmail.com','Austin123','Austin@123','6-FEB-1977', 'M','Austin','May','UTA blvd','arlington','TX',76020);
Insert into Customer values ('Anthony@gmail.com','Anthony123','Anthony@123', '1-FEB-1982', 'M','Anthony','Joseph','tist','Houston','TX',77002);
Insert into Customer values ('Louis@gmail.com', 'Louis123','Louis@123', '7-DEC-1982', 'M','Louis','phil','king','Philadelphia','PA',19019);
Insert into Customer values ('Jayden@gmail.com','Jayden123', 'Jayden@123', '9-AUG-1982', 'M','Jayden','Mike','W.border','Austin','TX',78702);
Insert into Customer values ('Brian@gmail.com','Brian123' , 'Brian@123', '10-MAY-1982', 'M','Brian','James','hanki','Olympia','WA',98501);
Insert into Customer values ('Mason@gmail.com', 'Mason123','Mason@123','20-FEB-1982', 'M','Mason','Jake','Mest','Boston','MA',21190);
Insert into Customer values ('Kyle@gmail.com', 'Kyle123' ,'Kyle@123', '11-MAR-1982', 'M','Kyle','Sean','dern','Dallas','TX',75019);
Insert into Customer values ('Max@gmail.com','Max123','Max@123', '7-AUG-1982', 'M','Max','Glenn','trin','Chicago','IL',60056);
Insert into Customer values ('Brandon@gmail.com','Brandon123','Brandon@123','9-MAY-1987', 'M','Brandon','Gates','Jerry','San Francisco','CA',94106);

--------------------------------------------------------------------------------------------------------------
Employee Table:-

Insert into Employee values ('Noah@gmail.com','Noah123','Noah@123',6000,'Warehouse Worker','5-NOV-2015','8-JAN-1988', 'M','Noah','Bill','grin','Philadelphia','PA',19019,1002);
Insert into Employee values ('Jack@gmail.com','Jack123','Jack@123',10000,'Customer Service Rep','19-SEP-2015', '7-JUN-1982', 'M','Jack','sock','Pind','Los Angeles','CA',90001,1001);
Insert into Employee values ('Jill@gmail.com','Jill123','Jill@123',7000,'Warehouse Worker','1-JAN-2015', '9-JUL-1992', 'F','Jill','Wagner','Park','Los Angeles','CA',90001,1001);
Insert into Employee values ('Jason@gmail.com','Jason123','Jason@123',20000,'Assistant Supervisor','18-MAY-2013','21-MAR-1987', 'M','Jason','Mayer','Lever','New York','NY',10032,1002);
Insert into Employee values ('Mason@gmail.com','Mason123','Mason@123',7000,'Warehouse Worker','11-MAY-2013','11-MAY-1988', 'M','Mason','Joe','Lever','New York','NY',10033,1002);
Insert into Employee values ('Robert@gmail.com','Robert123','Robert@123',6000,'Warehouse Worker','15-DEC-2015','19-MAY-1988', 'M','Robert','Junior','Hind','Atlanta','GA',30305,1003);
Insert into Employee values ('Austin@gmail.com','Austin123','Austin@123',40000,'Supervisor','23-MAR-2013','6-FEB-1977', 'M','Austin','May','UTA blvd','arlington','TX',76020,1000);
Insert into Employee values ('Anthony@gmail.com','Anthony123','Anthony@123',25000,'Web Developer','1-JAN-2015','1-FEB-1982', 'M','Anthony','Joseph','tist','Houston','TX',77002,NULL);
Insert into Employee values ('Tyler@gmail.com','Tyler123','Tyler@123',55000,'Assistant Manager','25-DEC-2014','22-MAR-1983', 'M','Tyler','marn','Mith','Boston','MA',21100,1002);
Insert into Employee values ('Jayden@gmail.com','Jayden123', 'Jayden@123',7000 ,'Warehouse Worker','1-JAN-2014', '9-AUG-1982', 'F','Jayden','Mike','W.border','Austin','TX',78702,1000);
Insert into Employee values ('Brian@gmail.com','Brian123' , 'Brian@123',90000,'Manager','7-OCT-2013', '10-MAY-1982', 'M','Brian','James','hanki','Olympia','WA',98501,1001);
Insert into Employee values ('Mason@gmail.com', 'Mason123','Mason@123',45000,'Third Key Manager','11-FEB-2014','20-FEB-1982', 'M','Mason','Jake','Mest','Boston','MA',21190,1002);
Insert into Employee values ('Adam@gmail.com','Adam123','Adam@123', 9500,'Warehouse Worker','10-APR-2013','6-DEC-1987', 'M','Adam','Levine','hons','Knoxville','TN',37087,1003);
Insert into Employee values ('Maxwell@gmail.com','Maxwell123','Maxwell@123', 9500,'Warehouse Worker','20-APR-2013', '7-AUG-1982', 'M','Maxwell','Glenn','trin','Chicago','IL',60056,1004);
Insert into Employee values ('Spencer@gmail.com','Spencer123','Spencer@123',18000,'Assistant Supervisor','17-OCT-2013','17-JUN-1982', 'M','Spencer','Shawn','Shane','Chicago','IL',60615,1004);
Insert into Employee values ('Brandon@gmail.com','Brandon123','Brandon@123',6500,'Warehouse Worker','10-JUL-2014', '9-MAY-1987', 'M','Brandon','Gates','Jerry','San Francisco','CA',94106,1001);
Insert into Employee values ('Jane@gmail.com','Jane123','Jane@123',7000,'Warehouse Worker', '9-MAY-2014', '10-DEC-1996','M','Jane','Mitch','pral','Knoxville','TN',30014,1003);
Insert into Employee values ('Anna@gmail.com','Anna123','Anna@123',6000,'Warehouse Worker', '5-MAR-2015', '14-NOV-1997','F','Anna','Nicolls','Palace','Boulder','CO',80035,1005);
Insert into Employee values ('Jake@gmail.com','Jake123', 'Jake@123',7500 ,'Warehouse Worker','11-JAN-2014', '5-SEP-1982', 'M','Jake','Mike','border','Austin','TX',78702,1000);

------------------------------------------------------------------------------------------------------------------
Books Table:-
//Pearson
Insert into Books values(9781447928911,'Official Guide-PTE Academic','Pearson',1,'New','Education','Paperback',19.5,'sight','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values(9781405865234,'Sherlock Holmes Short Stories','Arthur Conan Doyle',2,'Used','Short Stories','Paperback',5,'trin','Chicago','IL',60056,'Maxwell@gmail.com');
Insert into Books values(9781405865852,'CHEMISTRY 2012 STUDENT EDITION','PRENTICE HALL',3,'New','Education','Hardcover',45,'E.border','arlington','TX',76010,'Jake@gmail.com');///inserted till this
Insert into Books values (9780205892723,'Greek Art and Archaeology','Pedley',5,'E-book','Art','Other',25,'Raymond','San Francisco','CA',94016,'Jack@gmail.com');
Insert into Books values (9780130971401,'Anthropological Thinking','Perry',1,'Used','Anthropology','Hardcover',69.99,'SouthWest','Chicago','IL',60007,'Maxwell@gmail.com');
Insert into Books values (9780134109879,'A Guide about Writing Film','Corrigan',9,'New','Film','Paperback',11.99,'Blvd','Boston','MA',21100,'Mason@gmail.com');
Insert into Books values (9780321911216,'Elementary Statistics','Ron Larson,Betsy Farber',2,'New','Statistics','Paperback',20.99,'Times','New York','NY',10011,'Mason@gmail.com');
Insert into Books values (9780134093413,'Campbell Biology','Lisa,Michael,Steven,Peter,Jane',11,'Used','Biology','Hardcover',34.99,'Deon','Miami','FL',33101,'Jane@gmail.com');
Insert into Books values (9780321701763,'Adobe Photoshop CS5','Adobe Creative Team',5,'E-book','Professional','Other',11,'border','Dallas','TX',75019,'Jake@gmail.com');
Insert into Books values (9780321701770,'Adobe Dreamweaver','Adobe Creative Team',6,'New','Professional','Hardcover',29,'hick','Seattle','WA',98101,'Jill@gmail.com');
Insert into Books values (9780133073003,'Adobe Illustrator:Design','Susan Lazear',2,'E-book','Fashion','Other',19.99,'Strip','Las Vegas','CA',88901,'Jack@gmail.com');
Insert into Books values (9780134128689,'Textiles','Sara Kadolph,Sara Marcketti',12,'New','Fashion','Paperback',125.99,'Golden Gate','San Francisco','CA',94010,'Jill@gmail.com');
Insert into Books values (9780139569968,'Vegetable Crops','Dennis R. Decoteau',2,'New','Agriculture','Paperback',99,'Sind','Atlanta','GA',30301,'Jane@gmail.com');
Insert into Books values (9780205892783,'Handbook: Livestock Management','Richard A. Battaglia',4,'New','Agriculture','Hardcover',85,'fight','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values (9780131594753,'Livestock Feeds and Feeding','Richard Kellems, David Church',6,'New','Agriculture','Paperback',29.99,'hirl','Nashville','TN',37011,'Jane@gmail.com');
Insert into Books values (9780321333056,'Gandhi: Pioneer Social Change','Tara Sethia',1,'New','History','Hardcover',55,'werst','Chicago','IL',60010,'Maxwell@gmail.com');
Insert into Books values (9780321394262,'Wu Zhao:Chinas Female Emperor','N.Harry Rothschild',1,'E-book','History','Other',32.70,'Corner','San Francisco','CA',94106,'Jill@gmail.com');
Insert into Books values (9780131405677,'Guide to Media Relations','Irv Schenkler,Tony Herrling',1,'E-book','Marketing','Other',23.90,'Rame Blvd','Boston','MA',21100,'Mason@gmail.com');
Insert into Books values (9780134143316,'Marketing Research','Alvin Burns,Ann,Ronald Bush',8,'New','Marketing','Paperback',69.99,'Chaples','New York','NY',10009,'Mason@gmail.com');
Insert into Books values (9780138800550,'Symphony','Preston Stedman',2,'New','Music','Paperback',105,'Mint','Chicago','IL',60687,'Maxwell@gmail.com');
Insert into Books values (9780132319669,'Voice for non-majors','Robërto Manusi',1,'E-book','Music','Other',59,'Justin','Miami','FL',33101,'Jane@gmail.com');
Insert into Books values (9780321127204,'Theory of Asset Pricing','George Pennacchi',1,'New','Finance','Hardcover',35,'ron','Dallas','TX',75019,'Jake@gmail.com');
Insert into Books values (9780130915689,'Advanced Corporate Finance','Joseph Ogden,Frank Jen,Philip',5,'E-book','Finance','Other',35.99,'Main','Las Vegas','CA',88901,'Jack@gmail.com');
Insert into Books values (9780133036091,'Computer Forensics','Marije Britz',3,'New','Computer','Hardcover',149.99,'hick','Seattle','WA',98101,'Jill@gmail.com');
Insert into Books values (9780672336232,'HTML and CSS','Laura,Rafe,Jennifer',2,'E-book','Computer','Other',45,'geary','San Francisco','CA',94112,'Jack@gmail.com');
Insert into Books values (9780205892743,'PHP','Julie',2,'New','Computer','Paperback',57,'orland','Denver','CO',80015,'Anna@gmail.com');
Insert into Books values (9780205892863,'Oracle','Ben',5,'E-book','Computer','Other',95,'mesquite','arlington','TX',76019,'Jake@gmail.com');
//Wiley
Insert into Books values (9781119404583,'Professional Visual Studio','Bruce Johnson',1,'New','Computer','Paperback',65,'yerk','Philadelphia','PA',19010,'Mason@gmail.com');
Insert into Books values (9781119404584,'Python for R Users','Ajay Ohri',5,'E-book','Computer','Other',26.99,'gink','Atlanta','GA',30301,'Jane@gmail.com');
Insert into Books values (9781119404585,'Making Youtube videos','Nick Willoughby',3,'E-book','Computer','Other',27.99,'Central Perk','New York','NY',10011,'Mason@gmail.com');
Insert into Books values (9781119404586,'Evolutionary Algorithms','Alain,Sana',4,'New','Computer','Paperback',89,'Lamer','Nashville','TN',37011,'Jane@gmail.com');
Insert into Books values (9781119404587,'Operating System Concepts','Abraham,Greg,Peter',7,'E-book','Computer','',25.49,'Sideway','Chicago','IL',60626,'Maxwell@gmail.com');
Insert into Books values (9781119404588,'Greek Art','John',1,'E-book','Art','Other',24,'East Blvd','Chicago','IL',60611,'Maxwell@gmail.com');
Insert into Books values (9781119404589,'Modern Art','Pam Meecham',4,'E-book','Art','Other',25,'gean','Chicago','IL',60040,'Maxwell@gmail.com');
Insert into Books values (9781119404590,'Global Art World','Jonathan Harris',2,'New','Art','Paperback',59.99,'Long','Las Vegas','CA',88901,'Jill@gmail.com');
Insert into Books values (9781119404591,'Digital Art Comparison','Tom Havard',7,'E-book','Art','Other',22,'lake','Miami','FL',33101,'Jane@gmail.com');
Insert into Books values (9781119404592,'Western Art and Wider World','Poley Sean',9,'New','Art','Hardcover',89.99,'Weiner','Austin','TX',78702,'Jake@gmail.com');
Insert into Books values (9781119404593,'Nikon 5700 for Dummies','Julie King',2,'E-book','Lifestyle','Other',20,'Jone','Nashville','TN',37013,'Jane@gmail.com');
Insert into Books values (9781119404594,'Photoshop Elements','Ted Pova',1,'Used','Lifestyle','Paperback',11,'Wints','Houston','TX',77001,'Jayden@gmail.com');
Insert into Books values (9781119404595,'Fashion For Dummies','Jill Martin',2,'E-book','Lifestyle','Other',25,'Maple','New York','NY',10011,'Mason@gmail.com');
Insert into Books values (9781119404596,'Power Yoga','Anand Swami',6,'Used','Lifestyle','Hardcover',12,'kond','Seattle','WA',98101,'Jill@gmail.com');
Insert into Books values (9781119404597,'Water Saving Tips','John Mcenroe',5,'E-book','Lifestyle','Other',23.40,'Baker','Houston','TX',77001,'Jake@gmail.com');
Insert into Books values (9781119404598,'Intellectual Property','Mike Mill',3,'New','Law','Paperback',95,'gran','San Francisco','CA',94112,'Jack@gmail.com');
Insert into Books values (9781119404599,'Cyber Security Law','Jeff',5,'E-book','Law','',17,'garden','Dallas','TX',75010,'Jake@gmail.com');
Insert into Books values (9781119404100,'Human Rights','Fred,Martin',8,'New','Law','Hardcover',67,'Linx','Atlanta','GA',30301,'Jane@gmail.com');
Insert into Books values (9781119404101,'Criminology','Hardley',7,'New','Law','Paperback',93,'lights','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values (9781119404102,'Cooking Basics','Lisa,Annie',3,'E-book','Food','Other',33,'Beach','Miami','FL',33111,'Jane@gmail.com');
Insert into Books values (9781119404103,'Vegan Cooking','Alexandra',5,'New','Food','Hardcover',100,'Ching Blvd','Chicago','IL',60613,'Maxwell@gmail.com');
Insert into Books values (9781119404104,'Raw Food','Nancy',4,'New','Food','Paperback',109,'lone','Miami','FL',33101,'Jane@gmail.com');
Insert into Books values (9781119404105,'Gluten-free Cooking','Danna',2,'E-book','Food','Other',21,'Onix','New York','NY',10032,'Mason@gmail.com');
Insert into Books values (9781119404106,'Inernational Cuisine','Nick Boja',1,'Used','Food','Paperback',14,'sight','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values (9781119404107,'7-Day Diet','Alan will',5,'E-book','Food','',25,'Mart','Boston','MA',02115,'Mason@gmail.com');
//McGraw Hill Education
Insert into Books values (9781308866857,'Inspire Science','Pedley mitch',5,'E-book','Science','Other',25,'N.Cooper','arlington','TX',76010,'Austin@gmail.com');
Insert into Books values (9781308866858,'Computer Science','Christopher',1,'E-book','Computer','Other',55,'Sean','Chicago','IL',60045,'Maxwell@gmail.com');
Insert into Books values (9781308866859,'Information Retrieval','Vipin Kumar',3,'New','Computer','Paperback',95.70,'Jeremy','San Francisco','CA',94102,'Jill@gmail.com');
Insert into Books values (9781308866860,'Basics of C','Denis Ritchee',9,'Used','Computer','Hardcover',15,'west','Nashville','TN',37013,'Jane@gmail.com');
Insert into Books values (9781308866861,'Greek Archaeology','Rose',5,'E-book','Science','Other',25,'S.Cooper','arlington','TX',76010,'Jake@gmail.com');
Insert into Books values (9781308866862,'Art and Archaeology','Mill Gredon',1,'New','Art','Hardcover',65,'Univ','Philadelphia','PA',19019,'Mason@gmail.com');
Insert into Books values (9781308866863,'Modern Artists','William',3,'Used','Art','Hardcover',31,'Ray','Los Angeles','CA',90001,'Jack@gmail.com');
Insert into Books values (9781308866864,'Artistic Excellence','Sharon',9,'E-book','Art','Other',19.99,'S.Cooper','arlington','TX',76010,'Austin@gmail.com');
Insert into Books values (9780205892765,'Mystic Period Art','John Pedro',4,'E-book','Art','Other',24,'Ranch','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9781308866866,'South Asian Recipes','Sanjeev',7,'New','Food','Paperback',120,'yale','Los Angeles','CA',90001,'Jill@gmail.com');
Insert into Books values (9781308866867,'Raw Food Diet','Milano',2,'E-book','Food','Other',27,'prague','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values (9781308866868,'Vegan Recipes','Jonas',1,'E-book','Food','Other',42,'Times Square','New York','NY',10021,'Mason@gmail.com');
Insert into Books values (9781308866869,'Best Foods for Life','Shawn mendes',5,'Used','Food','Hardcover',31,'Sorn','Chicago','IL',60067,'Maxwell@gmail.com');
Insert into Books values (9781308866870,'Fashion Boutique','prince',8,'E-book','Fashion','Other',15,'anis','Los Angeles','CA',90001,'Brandon@gmail.com');
Insert into Books values (9781308866871,'Fashion Tips for Men','Henry',2,'New','Fashion','Hardcover',154,'N.Mesquite','arlingt,on','TX',76010,'Jake@gmail.com');
Insert into Books values (9781308866872,'Fashion Tips for Women','Lisa Kudrow',11,'New','Fashion','Hardcover',87,'Pind','Los Angeles','CA',90001,'Jack@gmail.com');
Insert into Books values (9781308866873,'Ramp Walk Guide','Gilly',2,'E-book','Fashion','Other',11,'Waker','San Francisco','CA',94104,'Brandon@gmail.com');
Insert into Books values (9781308866874,'Dress yourself Up','Nicholas Cruze',1,'Used','Fashion','Paperback',20,'Ray','Los Angeles','CA',90009,'Brandon@gmail.com');
Insert into Books values (9781308866875,'Chemistry','John Mayer',2,'E-book','Education','Other',34,'Link','Los Angeles','CA',90001,'Jack@gmail.com');
Insert into Books values (9781308866876,'Physics','P.Mani',1,'New','Education','Hardcover',96.50,'Mayer','Philadelphia','PA',19019,'Mason@gmail.com');
Insert into Books values (9781308866877,'Discrete Mathematics','Ramanujan',3,'E-book','Education','Other',23,'Kily','Los Angeles','CA',90001,'Brandon@gmail.com');
Insert into Books values (9781308866878,'Life Science','Pinto Bell',4,'Used','Education','Hardcover',35,'Raint','Chicago','IL',60051,'Maxwell@gmail.com');
Insert into Books values (9781308866879,'Biology','Sean Michael',6,'E-book','Education','Other',57,'Mith','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9781308866880,'Great Exercise for Great Life','Bond',7,'E-book','Lifestyle','Other',36,'Cooper','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9781308866881,'Yoga Practices','Isha',7,'Used','Lifestyle','Paperback',12.99,'onete','Dallas','TX',75019,'Jayden@gmail.com');
Insert into Books values (9781308866882,'Keep your Body Fit','Lisa,Julia',8,'E-book','Lifestyle','Other',33.50,'pin','Houston','TX',77001,'Jake@gmail.com');
Insert into Books values (9781308866883,'Fitness','James',9,'New','Lifestyle','Paperback',87.50,'James','Miami','FL',33102,'Jane@gmail.com');
Insert into Books values (9781308866884,'Impact of Lifestyle','Adam Levine',5,'E-book','Lifestyle','Other',29.99,'UTD','Dallas','TX',75019,'Jayden@gmail.com');
//Oxford University Press
Insert into Books values (9780199679416,'The Book: A Global History','Michael Suarez',1,'E-book','History','Other',45,'ivery','Olympia','WA',98502,'Jill@gmail.com');
Insert into Books values (9780199679417,'Understanding Social Networks','Charles',5,'E-book','Computer','Other',65,'Jay','Los Angeles','CA',90001,'Jack@gmail.com')
Insert into Books values (9780199679418,'Ethics:Introduction','Simon Blackburn',2,'New','Professional','Paperback',94,'Chinatown','San Francisco','CA',94109,'Brandon@gmail.com');
Insert into Books values (9780199679419,'Renewable Energy','Godfrey Boyle',3,'E-book','Environmnet','Other',29,'hons','Knoxville','TN',37087,'Robert@gmail.com');
Insert into Books values (9780199679420,'Celtic Mythology','Philip Freeman',7,'New','History','Hardcover',76,'grin','Philadelphia','PA',19019,'Mason@gmail.com');
Insert into Books values (9780199679421,'The Quran','Abdul Hadeem',9,'Used','Religion','Paperback',22,'Birng','Austin','TX',78702,'Jake@gmail.com');
Insert into Books values (9780199679422,'Atlas','Oxford',6,'New','Geography','Hardcover',10,'Anarchy','Austin','TX',78702,'Jake@gmail.com');
Insert into Books values (9780199679423,'Crime and Criminology','Sue',4,'E-book','Law','Other',54,'Shane','Chicago','IL',60615,'Maxwell@gmail.com');
Insert into Books values (9780199679424,'Cybersecurity and Cyber War','Singer',3,'E-book','Art','Other',37,'Collins','San Francisco','CA',94105,'Brandon@gmail.com');
Insert into Books values (9780199679425,'Oxford American Dictionary','Oxford',2,'New','English','Paperback',10,'Coll','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9780199679426,'Quantum Physics','Michael',1,'E-book','Physics','Other',34,'Angle','Austin','TX',78702,'Jake@gmail.com');
Insert into Books values (9780199679427,'American Poetry','David Lehman',1,'Used','Art','Hardcover',12,'Lever','New York','NY',10032,'Mason@gmail.com');
Insert into Books values (9780199679428,'English Grammar','Oxford Press',5,'New','English','Hardcover',78,'Hind','Atlanta','GA',30305,'Robert@gmail.com');
Insert into Books values (9780199679429,'Pocket Dictionary-English','Oxford',9,'Used','English','Paperback',15,'UTA blvd','arlington','TX',76020,'Jayden@gmail.com');
Insert into Books values (9780199679430,'Concise English Dictionary','Oxford',11,'E-book','English','Other',25,'tist','Houston','TX',77002,'Jayden@gmail.com');

//Thomson Reuters
Insert into Books values (9780314697318,'Texas Penal Code','Thomson Reuters',7,'New','Law','Hardcover',48,'trin','Chicago','IL',60056,'Maxwell@gmail.com');
Insert into Books values (9780314697319,'California Probate Code','Thomson Reuters',9,'New','Law','Hardcover',98,'Jerry','San Francisco','CA',94106,'Brandon@gmail.com');
Insert into Books values (9780314697320,'Employment Discrimination Law and Litigation','Pedley',5,'New','Law','Hardcover',350,'E.border','arlington','TX',76010,'Jayden@gmail.com');
Insert into Books values (9780314697321,'Bankruptcy Court Decisions','Thomson Reuters',6,'New','Law','Hardcover',208,'Raymond','San Francisco','CA',94016,'Brandon@gmail.com');
//Readers Digest
Insert into Books values (9780895779779,'Laughter the best medicine','Readers Digest',5,'New','Entertainment','Hardcover',11.48,'werst','Chicago','IL',60010,'Maxwell@gmail.com');
Insert into Books values (9780895779780,'Selecciones','Sunset Strings',1,'E-book','Magazine','Other',1.67,'Corner','San Francisco','CA',94106,'Jack@gmail.com');
Insert into Books values (9780895779781,'Birds and Blooms','Readers Digest',1,'E-book','Magazine','Other',25,'Rame Blvd','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9780895779782,'Life reports','David brooks',1,'E-book','Magazine','Other',25,'Chaples','New York','NY',10009,'Mason@gmail.com');

//Harper Collins
Insert into Books values (9780205893637,'His Convict Wife','Lena Dowling',3,'E-book','Art','Other',5,'yerk','Philadelphia','PA',19010,'Mason@gmail.com');
Insert into Books values (9780205893638,'The Hideaway','Lauren',1,'New','Stories','Paperback',11.49,'gink','Atlanta','GA',30301,'Robert@gmail.com');
Insert into Books values (9780205893639,'The Problem of Pain','Lewis',2,'Used','Life','Paperback',3.99,'Central Perk','New York','NY',10011,'Mason@gmail.com');
Insert into Books values (9780205893640,'The Travelers Gift','Andy Andrews',3,'New','Stories','Hardcover',12.99,'Lamer','Nashville','TN',37011,'Robert@gmail.com');
Insert into Books values (9780205893641,'Charlottes Web','Gareth Williams',2,'E-book','Stories','',11,'Sideway','Chicago','IL',60626,'Maxwell@gmail.com');
Insert into Books values (9780205893642,'A Classic Christmas','Harper Collins',5,'E-book','Stories','Other',21,'East Blvd','Chicago','IL',60611,'Maxwell@gmail.com');
Insert into Books values (9780205893643,'The Graveyard Book','Neil Gaiman',5,'New','Life','hardcover',10,'gean','Chicago','IL',60040,'Maxwell@gmail.com');


-----------------------------------------------------------------------------------------------------------------
Warehouse Table:-

Insert into Warehouse values (1000,20000,'Austin(TX)');
Insert into Warehouse values (1001,35000,'Los Angeles(CA)');
Insert into Warehouse values (1002,55000,'New York(NY)');
Insert into Warehouse values (1003,30000,'Knoxville(TN)');
Insert into Warehouse values (1004,35000,'Illinois(IL)');
Insert into Warehouse values (1005,25000,'Boulder(CO)');
-------------------------------------------------------------------------------------------------------------------
Seller Table:-

Insert into Seller values (2000,'Great Books',450506349,9724147979,'E.Collins','Dallas','Texas',75098);
Insert into Seller values (2001,'Mayers',411328190,4231894653,'Shane','Knoxville','Tennessee',37901);
Insert into Seller values (2002,'Books Online',546981234,4158426975,'Golden','San Francisco','California',94016);
Insert into Seller values (2003,'Powells',325678881,8724676453,'Urban','Champaign','Illinois',61820);
Insert into Seller values (2004,'New Books',544796210,6462361894,'Times','New York','New York',10001);
Insert into Seller values (2005,'William',409176490,4231894653,'Mike','Nashville','Tennessee',37221);
Insert into Seller values (2006,'Barnes&noble',320104681,8729436532,'Maple','Chicago','Illinois',60007);
Insert into Seller values (2007,'Jenkins',571458290,6467926551,'Railway','Rochester','New York',10004);
Insert into Seller values (2008,'Biblio',521097256,7206497753,'Big','Boulder','Colorado',80301);
Insert into Seller values (2009,'LAbooks',570347397,3106838705,'Napier','Los Angeles','California',90005);
Insert into Seller values (2010,'Alibris',523613588,3034678653,'University','Denver','Colorado',80014);
Insert into Seller values (2011,'CloudNine',451986537,5124895309,'Westway','Austin','Texas',78708);

---------------------------------------------------------------------------------------------------------------------
Publisher Table:-

Insert into Publisher values(1200,'Pearson','E.Collins','Dallas','Texas',75096);
Insert into Publisher values(1201,'McGraw-Hill Education','Trans','New York','New York',10008);
Insert into Publisher values(1202,'Wiley','North','Los Angeles','California',90001);
Insert into Publisher values(1203,'Oxford University Press','Gent','San Francisco','California',94016);
Insert into Publisher values(1204,'Thomson Reuters','Lake','Los Angeles','California',90017);
Insert into Publisher values(1205,'Readers Digest','Night','Knoxville','Tennessee',37905);
Insert into Publisher values(1206,'Harper Collins','Sean','Chicago','Illinois',60008);

----------------------------------------------------------------------------------------------------------------------

Customer_Card_Details Table:-

Insert into Customer_Card_Details values('david@gmail.com',4672892780234510,107,'VISA','David Beckham','1-AUG-2020');
Insert into Customer_Card_Details values ('elisa@gmail.com',4663853865386312,108,'VISA','Elisa Ray','1-MAY-2025');
Insert into Customer_Card_Details values ('brian@gmail.com',4726575310987613,109,'Mastercard','Brian Mike','1-DEC-2025');
Insert into Customer_Card_Details values ('tom@gmail.com' ,4726575310987614,110,'Mastercard','Tom Cruise','1-DEC-2025');
Insert into Customer_Card_Details values ('mike@gmail.com',4726575310987615,111,'VISA','Mike Jack','1-NOV-2020');
Insert into Customer_Card_Details values ('andy@gmail.com',4726575310987616,112,'Mastercard','Andy Murray','1-DEC-2020');
Insert into Customer_Card_Details values ('chris@gmail.com',4726575310987617,113,'Mastercard','Chris Nolan','1-AUG-2025');
Insert into Customer_Card_Details values ('ben@gmail.com', 4726575310987618,114,'Mastercard','Ben Ten','1-DEC-2025');
Insert into Customer_Card_Details values ('tuyen@gmail.com',4726575310987619,115,'VISA','Tuyen Lisa','1-MAY-2025');
Insert into Customer_Card_Details values ('nathan@gmail.com',4726575310987620,116,'Mastercard','Nathan Bryan','2-DEC-2025');
Insert into Customer_Card_Details values ('kelly@gmail.com',4726575310987621,117,'Mastercard','Kelly Ann','1-MAY-2025');
Insert into Customer_Card_Details values ('ricky@gmail.com',4726575310987622,118,'VISA','Ricky Martin','1-JAN-2022');
Insert into Customer_Card_Details values ('neil@gmail.com',4726575310987623,119,'Mastercard','Neil Nithin','1-APR-2023');
Insert into Customer_Card_Details values ('karen@gmail.com',4726575310987624,120,'Mastercard','Karen Fisher','1-AUG-2020');
Insert into Customer_Card_Details values ('paula@gmail.com',4726575310987625,121,'VISA','Paula July','1-JAN-2022');
Insert into Customer_Card_Details values ('cindy@gmail.com',4726575310987626,122,'Mastercard','Cindy Minx','1-DEC-2020');
Insert into Customer_Card_Details values ('carl@gmail.com',4726575310987627,123,'Mastercard','Carl Marx','1-APR-2023');
Insert into Customer_Card_Details values ('johnson12@gmail.com',4726575310987628,124,'VISA','Johnson Michael','1-MAY-2025');
Insert into Customer_Card_Details values ('michael1@gmail.com',4726575310987629,125,'Mastercard','Michael Shawn','1-JAN-2022');
Insert into Customer_Card_Details values ('selena5@gmail.com',4726575310987630,126,'Mastercard','Selena Gomez','1-DEC-2025');
Insert into Customer_Card_Details values ('peter8@gmail.com',4726575310987631,127,'VISA','Peter Pan','1-APR-2023');
Insert into Customer_Card_Details values ('pat@gmail.com',4726575310987632,128,'Mastercard','Patrick John','1-JAN-2022');
Insert into Customer_Card_Details values ('don@gmail.com',4726575310987633,129,'Mastercard','Donald Jones','1-DEC-2020');
Insert into Customer_Card_Details values ('james@gmail.com',4726575310987634,130,'VISA','James Anderson','1-MAY-2025');
Insert into Customer_Card_Details values ('alisha@gmail.com',4726575310987635,131,'Mastercard','Alisha Michelle','1-DEC-2025');
Insert into Customer_Card_Details values ('emily@gmail.com',4726575310987636,132,'Mastercard','Emily Clark','1-APR-2023');
Insert into Customer_Card_Details values ('aaliyah@gmail.com',4726575310987637,133,'VISA','Aaliyah Bhatt','1-AUG-2020');
Insert into Customer_Card_Details values ('jennifer@gmail.com',4726575310987638,134,'Mastercard','Jennifer Aniston','1-DEC-2025');
Insert into Customer_Card_Details values ('olivia@gmail.com',4726575310987639,135,'Mastercard','Olivia Austin','1-JAN-2022');
Insert into Customer_Card_Details values ('hannah@gmail.com',4726575310987640,136,'VISA','Hannah Montana','1-AUG-2020');
Insert into Customer_Card_Details values ('jessica@gmail.com',4726575310987641,137,'Mastercard','Jessica James','1-APR-2023');
Insert into Customer_Card_Details values ('sarah@gmail.com', 4726575310987642,138,'Mastercard','Sarah May','1-DEC-2025');
Insert into Customer_Card_Details values ('lily@gmail.com', 4726575310987643,139,'Mastercard','Lily Julie','1-JAN-2022');
Insert into Customer_Card_Details values ('savannah@gmail.com',4726575310987644,140,'VISA','Savannah Stone','1-DEC-2025');
Insert into Customer_Card_Details values ('isabella@gmail.com',4726575310987645,141,'Mastercard','Isabella Mary','1-DEC-2025');
Insert into Customer_Card_Details values ('sophia@gmail.com',4726575310987646,142,'VISA','Sophia Bary','1-AUG-2020');
Insert into Customer_Card_Details values ('ava@gmail.com',4726575310987647,143,'Mastercard','Ava Adam','1-DEC-2025');
Insert into Customer_Card_Details values ('grace@gmail.com',4726575310987648,144,'Mastercard','Grace Annie','1-APR-2023');
Insert into Customer_Card_Details values ('Mia@gmail.com',4726575310987649,145,'VISA','Mia Doll','1-APR-2023');
Insert into Customer_Card_Details values ('Ella@gmail.com',4726575310987650,146,'Mastercard','Ella Rose','1-MAY-2025');
Insert into Customer_Card_Details values ('alyssa@gmail.com',4726575310987651,147,'Mastercard','Alyssa Rose','1-JAN-2022');
Insert into Customer_Card_Details values ('lucy@gmail.com',4726575310987652,148,'VISA','Lucy Pinder','1-DEC-2025');
Insert into Customer_Card_Details values ('jade@gmail.com',4726575310987653,149,'Mastercard','Jade Steven','1-MAY-2025');
Insert into Customer_Card_Details values ('abby@gmail.com',4726575310987654,150,'Mastercard','Abby Brrok','1-DEC-2025');
Insert into Customer_Card_Details values ('kellie@gmail.com',4726575310987655,151,'VISA','Kellie Watson','1-MAY-2025' );
Insert into Customer_Card_Details values ('natalie@gmail.com',4726575310987656,152,'Mastercard','Natalie Gulbis','1-DEC-2025');
Insert into Customer_Card_Details values ('amanda@gmail.com', 4726575310987657,153,'Mastercard','Amanda Mills','1-DEC-2020');
Insert into Customer_Card_Details values ('bella@gmail.com',4726575310987658,154,'VISA','Bella Reese','1-DEC-2025');
Insert into Customer_Card_Details values ('rachel@gmail.com',4726575310987658,155,'Mastercard','Rachael Green','1-APR-2023');
Insert into Customer_Card_Details values ('taylor@gmail.com',4726575310987660,156,'Mastercard','Taylor Swift','1-MAY-2025');
Insert into Customer_Card_Details values ('alexis@gmail.com',4726575310987661,157,'VISA','Alexis Ford','1-DEC-2025');
Insert into Customer_Card_Details values ('paige@gmail.com',4726575310987662,158,'Mastercard','Paige Rose','1-DEC-2020');
Insert into Customer_Card_Details values ('jacob@gmail.com',4726575310987663,159,'VISA','Jacob John','1-DEC-2025');
Insert into Customer_Card_Details values ('Shawn@gmail.com',4726575310987664,160,'Mastercard','Shawn Shape','1-DEC-2025');
Insert into Customer_Card_Details values ('Muhammad@gmail.com',4726575310987665,161,'Mastercard','Muhammas Nazar','1-MAY-2025');
Insert into Customer_Card_Details values ('Aaron@gmail.com',4726575310987666,162,'VISA','Aaron Finch','1-DEC-2020');
Insert into Customer_Card_Details values ('Daniel@gmail.com', 4726575310987667,163,'VISA','Daniel Robin','1-JAN-2022');
Insert into Customer_Card_Details values ('Alex@gmail.com',4726575310987668,164,'Mastercard','Alex John','1-APR-2023');
Insert into Customer_Card_Details values ('Jonah@gmail.com', 4726575310987669,165,'Mastercard','Jonah Bren','1-DEC-2025');
Insert into Customer_Card_Details values ('Michael@gmail.com',4726575310987670,166,'VISA','Michael Shen','1-JAN-2022');
Insert into Customer_Card_Details values ('James@gmail.com',4726575310987671,167,'Mastercard','James Chris','1-DEC-2025');
Insert into Customer_Card_Details values ('Ryan@gmail.com',4726575310987672,168,'VISA','Ryan Reynold','1-DEC-2025');
Insert into Customer_Card_Details values ('Liam@gmail.com',4726575310987673,169,'Mastercard','Liam Neeson','1-JAN-2022');
Insert into Customer_Card_Details values ('David@gmail.com',4726575310987674,170,'Mastercard','David Levin','1-DEC-2025');
Insert into Customer_Card_Details values ('Mathew@gmail.com',4726575310987675,171,'VISA','Mathew Hayden','1-DEC-2020');
Insert into Customer_Card_Details values ('Jack@gmail.com',4726575310987676,172,'Mastercard','Jack Sock','1-JAN-2022');
Insert into Customer_Card_Details values ('Ethan@gmail.com',4726575310987677,173,'Mastercard','Ethan Hunt','1-APR-2023');
Insert into Customer_Card_Details values ('Luke@gmail.com',4726575310987678,174,'VISA','Luke Wang','1-AUG-2020');
Insert into Customer_Card_Details values ('Jordan@gmail.com',4726575310987679,175,'Mastercard','Jordan Mike','1-DEC-2025');
Insert into Customer_Card_Details values ('Harry@gmail.com', 4726575310987680,176,'Mastercard','Harry Lane','1-DEC-2025');
Insert into Customer_Card_Details values ('Alexander@gmail.com',4726575310987681,177,'VISA','Alexander Bell','1-JAN-2022');
Insert into Customer_Card_Details values ('Ali@gmail.com',4726575310987682,178,'Mastercard','Ali Sharif','1-MAY-2025');
Insert into Customer_Card_Details values ('Tyler@gmail.com',4726575310987683,179,'VISA','Tyler Marn','1-JAN-2022');
Insert into Customer_Card_Details values ('Kevin@gmail.com',4726575310987684,180,'Mastercard','Kevin Peter','1-APR-2023');
Insert into Customer_Card_Details values ('Joshua@gmail.com',4726575310987685,181,'Mastercard','Joshua Adam','1-AUG-2020');
Insert into Customer_Card_Details values ('Dylan@gmail.com',4726575310987686,182,'VISA','Dylan Rider','1-DEC-2025');
Insert into Customer_Card_Details values ('Blake@gmail.com',4726575310987687,183,'Mastercard','Blake John','1-APR-2023');
Insert into Customer_Card_Details values ('Andrew@gmail.com',4726575310987688,184,'VISA','Andrew Tye','1-MAY-2025');
Insert into Customer_Card_Details values ('Zayn@gmail.com',4726575310987689,185,'Mastercard','Zayn David','1-DEC-2025');
Insert into Customer_Card_Details values ('Christopher@gmail.com',4726575310987690,186,'VISA','Christopher Night','1-AUG-2020');
Insert into Customer_Card_Details values ('Johnnn@gmail.com',4726575310987691,187,'Mastercard','John Leger','1-DEC-2025');
Insert into Customer_Card_Details values ('Adam@gmail.com',4726575310987692,188,'Mastercard','Adam Levine','1-MAY-2025');
Insert into Customer_Card_Details values ('Noah@gmail.com',4726575310987693,189,'VISA','Noah Bill','1-DEC-2025');
Insert into Customer_Card_Details values ('William@gmail.com',4726575310987694,190,'Mastercard','William Mason','1-DEC-2020');
Insert into Customer_Card_Details values ('Aiden@gmail.com',4726575310987695,191,'VISA','Aiden Mills','1-DEC-2025');
Insert into Customer_Card_Details values ('Spencer@gmail.com',4726575310987696,192,'Mastercard','Spencer Shawn','1-DEC-2025');
Insert into Customer_Card_Details values ('Nathan@gmail.com',4726575310987697,193,'Mastercard','Nathan Lyon','1-DEC-2020');
Insert into Customer_Card_Details values ('Niall@gmail.com', 4726575310987698,194,'VISA','Niall Horan','1-AUG-2020');
Insert into Customer_Card_Details values ('Logan@gmail.com',4726575310987699,195,'Mastercard','Logan Hulk','1-APR-2023');
Insert into Customer_Card_Details values ('Jason@gmail.com',4726575310987701,196,'VISA','Jason Mayer','1-DEC-2020');
Insert into Customer_Card_Details values ('Robert@gmail.com',4726575310987702,197,'Mastercard','Robert Junior','1-DEC-2025');
Insert into Customer_Card_Details values ('Austin@gmail.com',4726575310987703,198,'VISA','Austin May','1-DEC-2020');
Insert into Customer_Card_Details values ('Anthony@gmail.com',4726575310987704,199,'Mastercard','Anthony Joseph','1-MAY-2025');
Insert into Customer_Card_Details values ('Louis@gmail.com', 4726575310987705,200,'VISA','Louis Phil','1-APR-2023');
Insert into Customer_Card_Details values ('Jayden@gmail.com',4726575310987706,201,'Mastercard','Jayden Mike','1-DEC-2025');
Insert into Customer_Card_Details values ('Brian@gmail.com',4726575310987707,202,'VISA','Brian James','1-AUG-2020');
Insert into Customer_Card_Details values ('Mason@gmail.com', 4726575310987708,203,'Mastercard','Mason Jake','1-DEC-2025');
Insert into Customer_Card_Details values ('Kyle@gmail.com', 4726575310987709,204,'VISA','Kyle Sean','1-AUG-2020');
Insert into Customer_Card_Details values ('Max@gmail.com',4726575310987710,205,'Mastercard','Max Glenn','1-APR-2023');
Insert into Customer_Card_Details values ('Brandon@gmail.com',4726575310987711,206,'VISA','Brandon Gates','1-MAY-2025');
----------------------------------------------------------------------------------------------------------------------------
Buys Table:-

Insert into Buys values('michael1@gmail.com',9780132319669,'11-MAR-2016',7,63.13);
Insert into Buys values ('sarah@gmail.com',9781119404589,'12-MAY-2016',10.25,27.56);
Insert into Buys values ('Jack@gmail.com',9781308866872,'13-AUG-2016',7.50,93.52);
Insert into Buys values ('emily@gmail.com' ,9780205893637,'14-JAN-2017',8,5.4);
Insert into Buys values ('Noah@gmail.com',9780199679420,'15-FEB-2017',8,82.08);
Insert into Buys values ('michael1@gmail.com',9781308866860,'16-MAY-2016',7,63.13);
Insert into Buys values ('Max@gmail.com',9780314697318,'17-MAY-2016',10.25,52.92);
Insert into Buys values ('Nathan@gmail.com',9780199679424,'30-NOV-2016',8.5,40.15);
Insert into Buys values ('jennifer@gmail.com',9780205893639,'19-MAY-2016',8.875,4.34);
Insert into Buys values ('Austin@gmail.com',9781119404592,'20-DEC-2016',6.25,95.61);
Insert into Buys values ('Anthony@gmail.com',9781308866861,'02-DEC-2016',6.25,29);
Insert into Buys values('ricky@gmail.com',9781447928911,'11-JUN-2016',7.50,23);
Insert into Buys values('Spencer@gmail.com',9781405865234,'17-DEC-2016',7,6.4);
Insert into Buys values('Spencer@gmail.com',9781405865852,'01-NOV-2017',7,52);
Insert into Buys values('ricky@gmail.com',9781405865234,'17-DEC-2016',7.50,52);
Insert into Buys values('Nathan@gmail.com',9780205892723,'23-FEB-2016',8,27.99);
Insert into Buys values('johnson12@gmail.com',9780130971401,'10-MAR-2016',7.50,72.99);
Insert into Buys values('taylor@gmail.com',9780134109879,'14-MAY-2017',8,13.99);
Insert into Buys values('grace@gmail.com',9780321911216,'09-FEB-2016',8.5,21.99);
Insert into Buys values('andy@gmail.com',9780134093413,'25-NOV-2017',7,35.99);
Insert into Buys values('chris@gmail.com',9780321701763,'23-DEC-2016',6.25,14);
Insert into Buys values('ben@gmail.com',9780321701770,'27-JAN-2017',7,34);
Insert into Buys values('tuyen@gmail.com',9780133073003,'11-FEB-2016',8,23.99);
Insert into Buys values('peter8@gmail.com',9780134128689,'12-APR-2016',8,128.99);
Insert into Buys values('jade@gmail.com',9780139569968,'16-JUN-2016',7.50,104);
Insert into Buys values('james@gmail.com',9780205892783,'18-JUL-2017',7,89);
Insert into Buys values('olivia@gmail.com',9780131594753,'10-AUG-2016',6.5,32.99);
Insert into Buys values('johnson12@gmail.com',9780321333056,'06-APR-2016',7.50,59);
Insert into Buys values('tuyen@gmail.com',9780321394262,'22-FEB-2017',8,36.50);
Insert into Buys values('taylor@gmail.com',9780131405677,'19-SEP-2016',8,27);
Insert into Buys values('grace@gmail.com',9780134143316,'02-FEB-2016',8.5,72.99);
Insert into Buys values('tuyen@gmail.com',9780321701763,'27-FEB-2017',8,25.14);

Insert into Buys values('bella@gmail.com',9780130915689,'17-FEB-2017',6,35.99);
Insert into Buys values('rachel@gmail.com',9780133036091,'27-MAR-2017',10,149.99);
Insert into Buys values('taylor@gmail.com',9780672336232,'15-MAR-2017',7,45);
Insert into Buys values('alexis@gmail.com',9780205892743,'25-APR-2017',7,57);
Insert into Buys values('paige@gmail.com',9780205892863,'07-APR-2017',8,95  );
Insert into Buys values('jacob@gmail.com',9781119404583,'02-MAY-2017',7,65);
Insert into Buys values('Shawn@gmail.com',9781119404584,'13-MAY-2017',6,26.99);
Insert into Buys values('Muhammad@gmail.com',9781119404585,'03-JUN-2017',6,27.99);
Insert into Buys values('Aaron@gmail.com',9781119404586,'14-JUN-2017',7,89);
Insert into Buys values('Daniel@gmail.com',9781119404587,'04-JUL-2017',5,25.49);
Insert into Buys values('Alex@gmail.com',9781119404588,'15-JUL-2017',6,24);
Insert into Buys values('Jonah@gmail.com',9781119404589,'05-AUG-2017',6,25);
Insert into Buys values('Michael@gmail.com',9781119404590 ,'16-AUG-2017',7,59.99);
Insert into Buys values('James@gmail.com',9781119404591,'28-AUG-2017',6,22);
Insert into Buys values('Ryan@gmail.com',9781119404592,'06-SEP-2017',7,89.99);
Insert into Buys values('Liam@gmail.com',9781119404593 ,'17-SEP-2017',6,20);
Insert into Buys values('David@gmail.com',9781119404594,'07-OCT-2017',6,11);
Insert into Buys values('Mathew@gmail.com',9781119404595,'18-OCT-2017',6,25);
Insert into Buys values('Jack@gmail.com',9781119404596,'02-NOV-2017',6,12);
Insert into Buys values('Ethan@gmail.com',9781119404597,'10-NOV-2017',6,23.40);


------------------------------------------------------------------------------------------------------------------------------
Publishes Table:-

Insert into Publishes values(1200,9780132319669);
Insert into Publishes values (1202,9781119404589);
Insert into Publishes values (1201,9781308866872);
Insert into Publishes values (1206,9780205893637);
Insert into Publishes values (1203,9780199679420);
Insert into Publishes values (1200,9780205893637);
Insert into Publishes values (1204,9780314697318);
Insert into Publishes values (1203,9780199679424);
Insert into Publishes values (1206,9780205893639);
Insert into Publishes values (1202,9781119404592);
--------------------------------------------------------------------------------------------------------------------------------

Sells Table:-

Insert into Sells values(2001,9780132319669,50);
Insert into Sells values (2010,9781119404589,19);
Insert into Sells values (2000,9781308866872,75);
Insert into Sells values (2006,9780205893637,3);
Insert into Sells values (2003,9780199679420,66);
Insert into Sells values (2001,9781308866872,50);
Insert into Sells values (2004,9780314697318,39);
Insert into Sells values (2000,9780199679424,32);
Insert into Sells values (2006,9780205893639,2.5);
Insert into Sells values (2009,9781119404592,80);
Insert into Sells values (2000,9780133073003,19.99);
Insert into Sells values (2000,9781308866872,49);
--------------------------------------------------------------------------------------------------------------------------------
Stocks Table:-

Insert into Stocks values(1001,9780132319669);
Insert into Stocks values (1004,9781119404589);
Insert into Stocks values (1000,9781308866872);
Insert into Stocks values (1005,9780205893637);
Insert into Stocks values (1003,9780199679420);
Insert into Stocks values (1001,9781308866872);
Insert into Stocks values (1004,9780314697318);
Insert into Stocks values (1000,9780199679424);
Insert into Stocks values (1002,9780205893639);
Insert into Stocks values (1005,9781119404592);
Insert into Stocks values (1005,9780132319669);
Insert into Stocks values (1003,9780132319669);