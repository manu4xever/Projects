------------------------------Script to insert the sample data to all tables----------------------------------
Customer Table:-

Insert into Customer values('david@gmail.com','david123','david@123','1999-03-11', 'M','david','beckham','E.border','arlington','TX',76010);
Insert into Customer values ('elisa@gmail.com','elisa123','elisa@123','1995-05-12', 'F','elisa','ray','Raymond','San Francisco','CA',94016);
Insert into Customer values ('brian@gmail.com','briann123','briann@123','1991-08-13', 'M','brian','mike','SouthWest','Chicago','IL',60007);
Insert into Customer values ('tom@gmail.com' ,'tom123','tom@123','1992-01-14', 'M','tom','cruise','Blvd','Boston','MA',21100);
Insert into Customer values ('mike@gmail.com','mike123','mike@123', '1993-02-15', 'M','mike','jack','Times','New York','NY',10011);
Insert into Customer values ('andy@gmail.com','andy123','andy@123', '1988-06-16', 'M','andy','murray','Deon','Miami','FL',33101);
Insert into Customer values ('chris@gmail.com','chris123','chris@123','1966-08-17', 'M','chris','nolan','border','Dallas','TX',75019);
Insert into Customer values ('ben@gmail.com', 'ben123', 'ben@123', '1956-10-18', 'M','ben','ten','hick','Seattle','WA',98101);
Insert into Customer values ('tuyen@gmail.com','tuyen123','tuyen@123', '1988-05-19', 'F','tuyen','lisa','Strip','Las Vegas','CA',88901);
Insert into Customer values ('nathan@gmail.com','nathan123','nathan@123', '1994-12-20', 'M','nathan','bryan','Golden Gate','San Francisco','CA',94010);
Insert into Customer values ('kelly@gmail.com','kelly123','kelly@123', '1992-03-21', 'F','kelly','ann','Sind','Atlanta','GA',30301);
Insert into Customer values ('ricky@gmail.com','ricky123', 'ricky@123', '1999-05-01', 'M','ricky','03tin','fight','Denver','CO',80014);
Insert into Customer values ('neil@gmail.com','neil123','neil@123', '1965-01-01', 'M','neil','nithin','hirl','Nashville','TN',37011);
Insert into Customer values ('karen@gmail.com','karen123','karen@123','1970-03-12', 'F','karen','fisher','werst','Chicago','IL',60010);
Insert into Customer values ('paula@gmail.com','paula123','paula@123','1975-07-16', 'F','paula','07y','Corner','San Francisco','CA',94106);
Insert into Customer values ('cindy@gmail.com','cindy123','cindy@123','1980-08-23', 'F','cindy','minx','Rame Blvd','Boston','MA',21100);
Insert into Customer values ('carl@gmail.com','carl123', 'carl@123','1970-03-08', 'M','carl','03x','Chaples','New York','NY',10009);
Insert into Customer values ('johnson12@gmail.com','johnson123', 'johnson@123', '1969-09-03', 'M','johnson','michael','Mint','Chicago','IL',60687); 
Insert into Customer values ('michael1@gmail.com','michael123', 'michael@123','1985-12-01', 'M','michael','shawn','Justin','Miami','FL',33101);
Insert into Customer values ('selena5@gmail.com','selena123', 'selena@123','1980-08-05', 'F','selena','gomez','ron','Dallas','TX',75019);
Insert into Customer values ('peter8@gmail.com','peter123', 'peter@123', '1988-08-06', 'M','peter','pan','Main','Las Vegas','CA',88901);
Insert into Customer values ('pat@gmail.com','patrick123', 'patrick@123','1981-10-08', 'M','patrick','john','hick','Seattle','WA',98101);
Insert into Customer values ('don@gmail.com','donald123','donald@123','1984-08-18', 'M','donald','jones','geary','San Francisco','CA',94112);
Insert into Customer values ('james@gmail.com','jamess123', 'jamess@123', '1988-05-19', 'M','james','anderson','orland','Denver','CO',80015);
Insert into Customer values ('alisha@gmail.com','alisha123','alisha@123','1982-02-20', 'F','alisha','michelle','mesquite','arlington','TX',76019);
Insert into Customer values ('emily@gmail.com','emily123','emily@123','1984-01-02', 'F','emily','clark','yerk','Philadelphia','PA',19010);
Insert into Customer values ('aaliyah@gmail.com','aaliyah123','aaliyah@123','1982-06-01', 'F','aaliyah','bhatt','gink','Atlanta','GA',30301);
Insert into Customer values ('jennifer@gmail.com','jennifer123','jennifer@123', '1986-08-20', 'F','jennifer','aniston','Central Perk','New York','NY',10011);
Insert into Customer values ('olivia@gmail.com', 'olivia123','olivia@123', '1999-06-03', 'F','olivia','austin','Lamer','Nashville','TN',37011);
Insert into Customer values ('hannah@gmail.com', 'hannah123','hannah@123', '1970-04-05', 'F','hannah','montana','Sideway','Chicago','IL',60626);
Insert into Customer values ('jessica@gmail.com','jessica123','jessica@123', '1985-07-12', 'F','jessica','james','East Blvd','Chicago','IL',60611);
Insert into Customer values ('sarah@gmail.com', 'sarah123','sarah@123','1982-10-05', 'F','sarah','05','gean','Chicago','IL',60040);
Insert into Customer values ('lily@gmail.com', 'lily123','lily@123','1979-02-28', 'F','lily','07ie','Long','Las Vegas','CA',88901);
Insert into Customer values ('savannah@gmail.com','savannah123', 'savannah@123', '1982-11-07', 'F','savannah','stone','lake','Miami','FL',33101);
Insert into Customer values ('isabella@gmail.com','isabella123','isabella@123','1985-05-08', 'F','isabella','03y','Weiner','Austin','TX',78702);
Insert into Customer values ('sophia@gmail.com','sophia123','sophia@123','1987-02-02', 'F','sophia','bary','Jone','Nashville','TN',37013);
Insert into Customer values ('ava@gmail.com','ava123','ava@123','1972-02-03', 'F','ava','adam','Wints','Houston','TX',77001);
Insert into Customer values ('grace@gmail.com','grace123','grace@123','1985-05-27', 'F','grace','annie','Maple','New York','NY',10011);
Insert into Customer values ('Mia@gmail.com','Mia123','Mia@123','1988-08-14', 'F','Mia','Doll','kond','Seattle','WA',98101);
Insert into Customer values ('Ella@gmail.com','Ella123','Ella@123','1999-05-20', 'F','Ella','rose','Baker','Houston','TX',77001);
Insert into Customer values ('alyssa@gmail.com','alyssa123','alyssa@123', '1995-01-01', 'F','alyssa','rose','gran','San Francisco','CA',94112);
Insert into Customer values ('lucy@gmail.com','lucy123', 'lucy@123','1985-12-31', 'F','lucy','pinder','garden','Dallas','TX',75010);
Insert into Customer values ('jade@gmail.com','jade123','jade123','1987-08-29', 'F','jade','steven','Linx','Atlanta','GA',30301);
Insert into Customer values ('abby@gmail.com','abby123','abby@123','1982-02-23', 'F','abby','brrok','lights','Denver','CO',80014);
Insert into Customer values ('kellie@gmail.com', 'kellie123','kellie@123','1982-01-05', 'F','kellie','watson','Beach','Miami','FL',33111);
Insert into Customer values ('natalie@gmail.com','natalie123','natalie@123','1985-02-06', 'F','natalie','gulbis','Ching Blvd','Chicago','IL',60613);
Insert into Customer values ('amanda@gmail.com', 'amanda123','amanda@123','1988-05-20', 'F','amanda','mills','lone','Miami','FL',33101);
Insert into Customer values ('bella@gmail.com','bella123','bella@123','1999-02-22', 'F','bella','reese','Onix','New York','NY',10032);
Insert into Customer values ('rachel@gmail.com','rachel123','rachel@123', '1999-05-05', 'F','rachel','green','sight','Denver','CO',80014);
Insert into Customer values ('taylor@gmail.com','taylor123','taylor@123','1981-02-19', 'F','taylor','swift','03t','Boston','MA',21150);
Insert into Customer values ('alexis@gmail.com','alexis123','alexis@123', '1995-05-11', 'F','alexis','ford','N.Cooper','arlington','TX',76010);
Insert into Customer values ('paige@gmail.com','paige123', 'paige@123', '1982-02-14', 'F','paige','rose','Sean','Chicago','IL',60045);
Insert into Customer values ('jacob@gmail.com','Jacob123', 'Jacob@123', '1982-06-07', 'M','Jacob','John','Jeremy','San Francisco','CA',94102);
Insert into Customer values ('Shawn@gmail.com','Shawnn123', 'Shawnn@123','1982-07-05', 'M','Shawn','Shape','west','Nashville','TN',37013);
Insert into Customer values ('Muhammad@gmail.com','Muhammadd123', 'Muhammadd@123','1985-09-08', 'M','Muhammad','Nazar','S.Cooper','arlington','TX',76010);
Insert into Customer values ('Aaron@gmail.com','Aaronn123', 'Aaronn@123','1982-06-03', 'M','Aaron','finch','Univ','Philadelphia','PA',19019);
Insert into Customer values ('Daniel@gmail.com', 'Daniell123', 'Daniell@123','1982-08-06', 'M','Daniel','robin','Ray','Los Angeles','CA',90001);
Insert into Customer values ('Alex@gmail.com','Alexx123', 'Alexx@123', '1982-03-05', 'M','Alex','john','S.Cooper','arlington','TX',76010);
Insert into Customer values ('Jonah@gmail.com', 'Jonah123', 'Jonah@123','1988-06-12', 'M','Jonah','bren','Ranch','Boston','MA',21100);
Insert into Customer values ('Michael@gmail.com','Michaell123', 'Michaell@123', '1982-08-03', 'M','Michael','shen','yale','Los Angeles','CA',90001);
Insert into Customer values ('James@gmail.com','James123','James@123', '1988-09-05', 'M','James','chris','prague','Denver','CO',80014);
Insert into Customer values ('Ryan@gmail.com','Ryann123','Ryann@123', '1991-06-20', 'M','Ryan','Ronald','Times Square','New York','NY',10021);
Insert into Customer values ('Liam@gmail.com','Liam123','Liam@123', '1982-02-08', 'M','Liam','Neeson','Sorn','Chicago','IL',60067);
Insert into Customer values ('David@gmail.com','Davidd123','Davidd@123','1982-01-02', 'M','David','Levin','anis','Los Angeles','CA',90001);
Insert into Customer values ('Mathew@gmail.com','Matheww123', 'Matheww@123', '1982-05-05', 'M','Mathew','Hayden','N.Mesquite','arlington','TX',76010);
Insert into Customer values ('Jack@gmail.com','Jackk123','Jackk@123', '1982-07-06', 'M','Jack','sock','Pind','Los Angeles','CA',90001);
Insert into Customer values ('Ethan@gmail.com','Ethan123','Ethan@123','1982-09-08', 'M','Ethan','Hunt','Waker','San Francisco','CA',94104);
Insert into Customer values ('Luke@gmail.com','Luke123','Luke@123','1982-03-08', 'M','Luke','wang','Ray','Los Angeles','CA',90009);
Insert into Customer values ('Jordan@gmail.com','Jordan123','Jordan@123','1982-05-05', 'M','Jordan','Mike','Link','Los Angeles','CA',90001);
Insert into Customer values ('Harry@gmail.com', 'Harry123','Harry@123','1982-02-12', 'M','Harry','Lane','05er','Philadelphia','PA',19019);
Insert into Customer values ('Alexander@gmail.com','Alexander123','Alexander@123','1982-06-02', 'M','Alexander','bell','Kily','Los Angeles','CA',90001);
Insert into Customer values ('Ali@gmail.com','Ali123','Ali@123', '1981-11-03', 'M','Ali','sharif','Raint','Chicago','IL',60051);
Insert into Customer values ('Tyler@gmail.com','Tyler123','Tyler@123','1983-03-22', 'M','Tyler','03n','Mith','Boston','MA',21100);
Insert into Customer values ('Kevin@gmail.com','Kevin123','Kevin@123','1987-01-17', 'M','Kevin','peter','Cooper','Boston','MA',21100);
Insert into Customer values ('Joshua@gmail.com','Joshua123','Joshua@123', '1984-08-03', 'M','joshua','adam','onete','Dallas','TX',75019);
Insert into Customer values ('Dylan@gmail.com','Dylan123','Dylan@123','1985-02-01', 'M','Dylan','Rider','pin','Houston','TX',77001);
Insert into Customer values ('Blake@gmail.com','Blake123','Blake@123','1986-05-08', 'M','Blake','John','James','Miami','FL',33102);
Insert into Customer values ('Andrew@gmail.com','Andrew123','Andrew@123', '1982-08-05', 'M','Andrew','Tye','UTD','Dallas','TX',75019);
Insert into Customer values ('Zayn@gmail.com','Zayn123','Zayn@123','1999-04-12', 'M','Zayn','David','ivery','Olympia','WA',98502);
Insert into Customer values ('Christopher@gmail.com','Christopher123','Christopher@123', '1985-08-22', 'M','Christopher','Night','Jay','Los Angeles','CA',90001);
Insert into Customer values ('Johnnn@gmail.com','John123','John@123', '1984-08-14', 'M','John','Leger','Chinatown','San Francisco','CA',94109);
Insert into Customer values ('Adam@gmail.com','Adam123','Adam@123', '1987-06-12', 'M','Adam','Levine','hons','Knoxville','TN',37087);
Insert into Customer values ('Noah@gmail.com','Noah123','Noah@123','1988-08-01', 'M','Noah','Bill','grin','Philadelphia','PA',19019);
Insert into Customer values ('William@gmail.com','William123','William@123', '1984-09-03', 'M','William','Mason','Birng','Austin','TX',78702);
Insert into Customer values ('Aiden@gmail.com','Aiden123','Aiden@123', '1985-11-03', 'M','Aiden','mills','Anarchy','Austin','TX',78702);
Insert into Customer values ('Spencer@gmail.com','Spencer123','Spencer@123','1982-06-17', 'M','Spencer','Shawn','Shane','Chicago','IL',60615);
Insert into Customer values ('Nathan@gmail.com','Nathann123','Nathann@123' ,'1982-11-07', 'M','Nathan','Lyon','Collins','San Francisco','CA',94105);
Insert into Customer values ('Niall@gmail.com', 'Niall123','Niall@123','1999-07-08', 'M','Niall','Horan','Coll','Boston','MA',21100);
Insert into Customer values ('Logan@gmail.com','Logan123','Logan@123', '1985-08-03', 'M','Logan','Hulk','Angle','Austin','TX',78702);
Insert into Customer values ('Jason@gmail.com','Jason123','Jason@123','1987-03-21', 'M','Jason','05er','Lever','New York','NY',10032);
Insert into Customer values ('Robert@gmail.com','Robert123','Robert@123','1988-05-19', 'M','Robert','06ior','Hind','Atlanta','GA',30305);
Insert into Customer values ('Austin@gmail.com','Austin123','Austin@123','1977-06-02', 'M','Austin','05','UTA blvd','arlington','TX',76020);
Insert into Customer values ('Anthony@gmail.com','Anthony123','Anthony@123', '1982-01-02', 'M','Anthony','Jo09h','tist','Houston','TX',77002);
Insert into Customer values ('Louis@gmail.com', 'Louis123','Louis@123', '1982-07-12', 'M','Louis','phil','king','Philadelphia','PA',19019);
Insert into Customer values ('Jayden@gmail.com','Jayden123', 'Jayden@123', '1982-09-08', 'M','Jayden','Mike','W.border','Austin','TX',78702);
Insert into Customer values ('Brian@gmail.com','Brian123' , 'Brian@123', '1982-10-05', 'M','Brian','James','hanki','Olympia','WA',98501);
Insert into Customer values ('Mason@gmail.com', 'Mason123','Mason@123','1982-02-20', 'M','Mason','Jake','Mest','Boston','MA',21190);
Insert into Customer values ('Kyle@gmail.com', 'Kyle123' ,'Kyle@123', '1982-11-03', 'M','Kyle','Sean','dern','Dallas','TX',75019);
Insert into Customer values ('Max@gmail.com','Max123','Max@123', '1982-07-08', 'M','Max','Glenn','trin','Chicago','IL',60056);
Insert into Customer values ('Brandon@gmail.com','Brandon123','Brandon@123','1987-09-05', 'M','Brandon','Gates','Jerry','San Francisco','CA',94106);

--------------------------------------------------------------------------------------------------------------
Employee Table:-

Insert into Employee values ('Noah@gmail.com','Noah123','Noah@123',6000,'Warehouse Worker','2015-05-11','1988-08-01', 'M','Noah','Bill','grin','Philadelphia','PA',19019,1002);

Insert into Employee values ('Jack@gmail.com','Jack123','Jack@123',10000,'Customer Service Rep','2015-09-19', '1982-07-06', 'M','Jack','sock','Pind','Los Angeles','CA',90001,1001);

Insert into Employee values ('Jill@gmail.com','Jill123','Jill@123',7000,'Warehouse Worker','2015-01-01', '1992-09-07', 'F','Jill','Wagner','Park','Los Angeles','CA',90001,1001);

Insert into Employee values ('Jason@gmail.com','Jason123','Jason@123',20000,'Assistant Supervisor','2013-08-05','1987-11-03', 'M','Jason','05er','Lever','New York','NY',10032,1002);

Insert into Employee values ('Mason@gmail.com','Mason123','Mason@123',7000,'Warehouse Worker','2013-11-05','1988-11-05', 'M','Mason','Joe','Lever','New York','NY',10033,1002);

Insert into Employee values ('Robert@gmail.com','Robert123','Robert@123',6000,'Warehouse Worker','2015-12-12','1988,10-05', 'M','Robert','06ior','Hind','Atlanta','GA',30305,1003);

Insert into Employee values ('Austin@gmail.com','Austin123','Austin@123',40000,'Supervisor','2013-03-23','1977-06-02', 'M','Austin','05','UTA blvd','arlington','TX',76020,1000);

Insert into Employee values ('Anthony@gmail.com','Anthony123','Anthony@123',25000,'Web Developer','01-01-2015','1982-01-02', 'M','Anthony','Jo09h','tist','Houston','TX',77002,NULL);

Insert into Employee values ('Tyler@gmail.com','Tyler123','Tyler@123',55000,'Assistant Manager','2014-02-12','1983-12-03', 'M','Tyler','03n','Mith','Boston','MA',21100,1002);

Insert into Employee values ('Jayden@gmail.com','Jayden123', 'Jayden@123',7000 ,'Warehouse Worker','2014,01-01', '1982-09-08', 'F','Jayden','Mike','W.border','Austin','TX',78702,1000);

Insert into Employee values ('Brian@gmail.com','Brian123' , 'Brian@123',90000,'Manager','2013-07-10', '1982-10-05', 'M','Brian','James','hanki','Olympia','WA',98501,1001);

Insert into Employee values ('Mason1@gmail.com', 'Mason1123','Mason@1123',45000,'Third Key Manager','2014-11-02','1982-12-02', 'M','Mason','Jake','Mest','Boston','MA',21190,1002);

Insert into Employee values ('Adam@gmail.com','Adam123','Adam@123', 9500,'Warehouse Worker','2013-10-04','1987-06-12', 'M','Adam','Levine','hons','Knoxville','TN',37087,1003);

Insert into Employee values ('Maxwell@gmail.com','Maxwell123','Maxwell@123', 9500,'Warehouse Worker','2013-12-04', '1982-07-08', 'M','Maxwell','Glenn','trin','Chicago','IL',60056,1004);

Insert into Employee values ('Spencer@gmail.com','Spencer123','Spencer@123',18000,'Assistant Supervisor','2013-07-10','1982-12-06', 'M','Spencer','Shawn','Shane','Chicago','IL',60615,1004);
Insert into Employee values ('Brandon@gmail.com','Brandon123','Brandon@123',6500,'Warehouse Worker','2014-10-07', '1987-09-05', 'M','Brandon','Gates','Jerry','San Francisco','CA',94106,1001);
Insert into Employee values ('mase@gmail.com','mase123','mase@123',7000,'Warehouse Worker', '2014-09-05', '1996-10-12','M','Mase','Mitch','pral','Knoxville','TN',30014,1003);
Insert into Employee values ('Anna@gmail.com','Anna123','Anna@123',6000,'Warehouse Worker', '2015-05-03-', '1997-04-11-','F','Anna','Nicolls','Palace','Boulder','CO',80035,1005);
Insert into Employee values ('Jake@gmail.com','Jake123', 'Jake@123',7500 ,'Warehouse Worker','2014-11-01', '1982-05-09', 'M','Jake','Mike','border','Austin','TX',78702,1000);

------------------------------------------------------------------------------------------------------------------
Books Table:-

Insert into Books values(9781447928911,'Official Guide-PTE Academic','Pearson',1,'New','Education','Paperback',19.5,'sight','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values(9781405865234,'Sherlock Holmes Short Stories','Arthur Conan Doyle',2,'Used','Short Stories','Paperback',5,'trin','Chicago','IL',60056,'Maxwell@gmail.com');
Insert into Books values(9781405865852,'CHEMISTRY 2012 STUDENT EDITION','PRENTICE HALL',3,'New','Education','Hardcover',45,'E.border','arlington','TX',76010,'Jake@gmail.com');
Insert into Books values (9780205892723,'Greek Art and Archaeology','Pedley',5,'E-book','Art','Other',25,'Raymond','San Francisco','CA',94016,'Jack@gmail.com');
Insert into Books values (9780130971401,'Anthropological Thinking','Perry',1,'Used','Anthropology','Hardcover',69.99,'SouthWest','Chicago','IL',60007,'Maxwell@gmail.com');
Insert into Books values (9780134109879,'A Guide about Writing Film','Corrigan',9,'New','Film','Paperback',11.99,'Blvd','Boston','MA',21100,'Mason@gmail.com');
Insert into Books values (9780321911216,'Elementary Statistics','Ron Larson,Betsy Farber',2,'New','Statistics','Paperback',20.99,'Times','New York','NY',10011,'Mason@gmail.com');
Insert into Books values (9780134093413,'Campbell Biology','Lisa,Michael,Steven,Peter,01e',11,'Used','Biology','Hardcover',34.99,'Deon','Miami','FL',33101,'mase@gmail.com');
Insert into Books values (9780321701763,'Adobe Photoshop CS5','Adobe Creative Team',5,'E-book','Professional','Other',11,'border','Dallas','TX',75019,'Jake@gmail.com');
Insert into Books values (9780321701770,'Adobe Dreamweaver','Adobe Creative Team',6,'New','Professional','Hardcover',29,'hick','Seattle','WA',98101,'Jill@gmail.com');
Insert into Books values (9780133073003,'Adobe Illustrator:Design','Susan Lazear',2,'E-book','Fashion','Other',19.99,'Strip','Las Vegas','CA',88901,'Jack@gmail.com');
Insert into Books values (9780134128689,'Textiles','Sara Kadolph,Sara 03cketti',12,'New','Fashion','Paperback',125.99,'Golden Gate','San Francisco','CA',94010,'Jill@gmail.com');
Insert into Books values (9780139569968,'Vegetable Crops','Dennis R. 12oteau',2,'New','Agriculture','Paperback',99,'Sind','Atlanta','GA',30301,'Noah@gmail.com');
Insert into Books values (9780205892783,'Handbook: Livestock Management','Richard A. Battaglia',4,'New','Agriculture','Hardcover',85,'fight','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values (9780131594753,'Livestock Feeds and Feeding','Richard Kellems, David Church',6,'New','Agriculture','Paperback',29.99,'hirl','Nashville','TN',37011,'mase@gmail.com');
Insert into Books values (9780321333056,'Gandhi: Pioneer of Nonviolent Social Change','Tara Sethia',1,'New','History','Hardcover',55,'werst','Chicago','IL',60010,'Maxwell@gmail.com');
Insert into Books values (9780321394262,'Wu Zhao:Chinas Only Female Emperor','N.Harry Rothschild',1,'E-book','History','Other',32.70,'Corner','San Francisco','CA',94106,'Jill@gmail.com');
Insert into Books values (9780131405677,'Guide to Media Relations','Irv Schenkler,Tony Herrling',1,'E-book','Marketing','Other',23.90,'Rame Blvd','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9780134143316,'Marketing Research','Alvin Burns,Ann Veeck,Ronald Bush',8,'New','Marketing','Paperback',69.99,'Chaples','New York','NY',10009,'Mason@gmail.com');
Insert into Books values (9780138800550,'Symphony','Preston Stedman',2,'New','Music','Paperback',105,'Mint','Chicago','IL',60687,'Maxwell@gmail.com');
Insert into Books values (9780132319669,'Voice for non-majors','Robërto Manusi',1,'E-book','Music','Other',59,'Justin','Miami','FL',33101,'mase@gmail.com');
Insert into Books values (9780321127204,'Theory of Asset Pricing','George Pennacchi',1,'New','Finance','Hardcover',35,'ron','Dallas','TX',75019,'Jake@gmail.com');
Insert into Books values (9780130915689,'Advanced Corporate Finance','Jo09h Ogden,Frank Jen,Philip',5,'E-book','Finance','Other',35.99,'Main','Las Vegas','CA',88901,'Jack@gmail.com');
Insert into Books values (9780133036091,'Computer Forensics','03ije Britz',3,'New','Computer','Hardcover',149.99,'hick','Seattle','WA',98101,'Jill@gmail.com');
Insert into Books values (9780672336232,'HTML and CSS','Laura Le05,Rafe Colburn,Jennifer',2,'E-book','Computer','Other',45,'geary','San Francisco','CA',94112,'Jack@gmail.com');
Insert into Books values (9780205892743,'PHP','07ie',2,'New','Computer','Paperback',57,'orland','Denver','CO',80015,'Anna@gmail.com');
Insert into Books values (9780205892863,'Oracle','Ben',5,'E-book','Computer','Other',95,'mesquite','arlington','TX',76019,'Jake@gmail.com');

Insert into Books values (9781119404583,'Professional Visual Studio','Bruce Johnson',1,'New','Computer','Paperback',65,'yerk','Philadelphia','PA',19010,'Mason@gmail.com');
Insert into Books values (9781119404584,'Python for R Users','Ajay Ohri',5,'E-book','Computer','Other',26.99,'gink','Atlanta','GA',30301,'mase@gmail.com');
Insert into Books values (9781119404585,'Making Youtube videos','Nick Willoughby',3,'E-book','Computer','Other',27.99,'Central Perk','New York','NY',10011,'Mason@gmail.com');
Insert into Books values (9781119404586,'Evolutionary Algorithms','Alain,Sana',4,'New','Computer','Paperback',89,'Lamer','Nashville','TN',37011,'mase@gmail.com');
Insert into Books values (9781119404587,'Operating System Concepts','Abraham,Greg,Peter',7,'E-book','Computer','',25.49,'Sideway','Chicago','IL',60626,'Maxwell@gmail.com');
Insert into Books values (9781119404588,'Greek Art','John',1,'E-book','Art','Other',24,'East Blvd','Chicago','IL',60611,'Maxwell@gmail.com');
Insert into Books values (9781119404589,'Modern Art','Pam Meecham',4,'E-book','Art','Other',25,'gean','Chicago','IL',60040,'Maxwell@gmail.com');
Insert into Books values (9781119404590,'Global Art World','Jonathan Harris',2,'New','Art','Paperback',59.99,'Long','Las Vegas','CA',88901,'Jill@gmail.com');
Insert into Books values (9781119404591,'Digital Art Comparison','Tom Havard',7,'E-book','Art','Other',22,'lake','Miami','FL',33101,'mase@gmail.com');
Insert into Books values (9781119404592,'Western Art and Wider World','Poley Sean',9,'New','Art','Hardcover',89.99,'Weiner','Austin','TX',78702,'Jake@gmail.com');
Insert into Books values (9781119404593,'Nikon 5700 for Dummies','07ie King',2,'E-book','Lifestyle','Other',20,'Jone','Nashville','TN',37013,'mase@gmail.com');
Insert into Books values (9781119404594,'Photoshop Elements','Ted Pova',1,'Used','Lifestyle','Paperback',11,'Wints','Houston','TX',77001,'Jayden@gmail.com');
Insert into Books values (9781119404595,'Fashion For Dummies','Jill 03tin',2,'E-book','Lifestyle','Other',25,'Maple','New York','NY',10011,'Mason@gmail.com');
Insert into Books values (9781119404596,'Power Yoga','Anand Swami',6,'Used','Lifestyle','Hardcover',12,'kond','Seattle','WA',98101,'Jill@gmail.com');
Insert into Books values (9781119404597,'Water Saving Tips','John Mcenroe',5,'E-book','Lifestyle','Other',40,'Baker','Houston','TX',77001,'Jake@gmail.com');
Insert into Books values (9781119404598,'Intellectual Property','Mike Mill',3,'New','Law','Paperback',95,'gran','San Francisco','CA',94112,'Jack@gmail.com');
Insert into Books values (9781119404599,'Cyber Security Law','Jeff',5,'E-book','Law','',17,'garden','Dallas','TX',75010,'Jake@gmail.com');
Insert into Books values (9781119404100,'Human Rights','Fred,03tin',8,'New','Law','Hardcover',67,'Linx','Atlanta','GA',30301,'mase@gmail.com');
Insert into Books values (9781119404101,'Criminology','Hardley',7,'New','Law','Paperback',93,'lights','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values (9781119404102,'Cooking Basics','Lisa,Annie',3,'E-book','Food','Other',33,'Beach','Miami','FL',33111,'mase@gmail.com');
Insert into Books values (9781119404103,'Vegan Cooking','Alexandra',5,'New','Food','Hardcover',100,'Ching Blvd','Chicago','IL',60613,'Maxwell@gmail.com');
Insert into Books values (9781119404104,'Raw Food','Nancy',4,'New','Food','Paperback',109,'lone','Miami','FL',33101,'mase@gmail.com');
Insert into Books values (9781119404105,'Gluten-free Cooking','Danna',2,'E-book','Food','Other',21,'Onix','New York','NY',10032,'Mason@gmail.com');
Insert into Books values (9781119404106,'Inernational Cuisine','Nick Boja',1,'Used','Food','Paperback',14,'sight','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values (9781119404107,'7-Day Diet','Alan will',5,'E-book','Food','',25,'03t','Boston','MA',02115,'Mason@gmail.com');

Insert into Books values (9781308866857,'Inspire Science','Pedley mitch',5,'E-book','Science','Other',25,'N.Cooper','arlington','TX',76010,'Austin@gmail.com');
Insert into Books values (9781308866858,'Computer Science','Christopher',1,'E-book','Computer','Other',55,'Sean','Chicago','IL',60045,'Maxwell@gmail.com');
Insert into Books values (9781308866859,'Information Retrieval','Vipin Ku03',3,'New','Computer','Paperback',95.70,'Jeremy','San Francisco','CA',94102,'Jill@gmail.com');
Insert into Books values (9781308866860,'Basics of C','Denis Ritchee',9,'Used','Computer','Hardcover',15,'west','Nashville','TN',37013,'mase@gmail.com');
Insert into Books values (9781308866861,'Greek Archaeology','Rose',5,'E-book','Computer','Other',25,'S.Cooper','arlington','TX',76010,'Jake@gmail.com');
Insert into Books values (9781308866862,'Art and Archaeology','Mill Gredon',1,'New','Art','Hardcover',65,'Univ','Philadelphia','PA',19019,'Mason@gmail.com');
Insert into Books values (9781308866863,'Modern Artists','William',3,'Used','Art','Hardcover',31,'Ray','Los Angeles','CA',90001,'Jack@gmail.com');
Insert into Books values (9781308866864,'Artistic Excellence','Sharon',9,'E-book','Art','Other',19.99,'S.Cooper','arlington','TX',76010,'Austin@gmail.com');
Insert into Books values (9780205892765,'Mystic Period Art','John Pedro',4,'E-book','Art','Other',24,'Ranch','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9781308866866,'South Asian Recipes','Sanjeev',7,'New','Food','Paperback',120,'yale','Los Angeles','CA',90001,'Jill@gmail.com');
Insert into Books values (9781308866867,'Raw Food Diet','Milano',2,'E-book','Food','Other',27,'prague','Denver','CO',80014,'Anna@gmail.com');
Insert into Books values (9781308866868,'Vegan Recipes','Jonas',1,'E-book','Food','Other',42,'Times Square','New York','NY',10021,'Mason@gmail.com');
Insert into Books values (9781308866869,'Best Foods for Life','Shawn mendes',5,'Used','Food','Hardcover',31,'Sorn','Chicago','IL',60067,'Maxwell@gmail.com');
Insert into Books values (9781308866870,'Fashion Boutique','prince',8,'E-book','Fashion','Other',15,'anis','Los Angeles','CA',90001,'Brandon@gmail.com');
Insert into Books values (9781308866871,'Fashion Tips for Men','Henry',2,'New','Fashion','Hardcover',154,'N.Mesquite','arlingt,on','TX',76010,'Jake@gmail.com');
Insert into Books values (9781308866872,'Fashion Tips for Women','Lisa Kudrow',11,'New','Fashion','Hardcover',87,'Pind','Los Angeles','CA',90001,'Jack@gmail.com');
Insert into Books values (9781308866873,'Ramp Walk Guide','Gilly',2,'E-book','Fashion','Other',11,'Waker','San Francisco','CA',94104,'Brandon@gmail.com');
Insert into Books values (9781308866874,'Dress yourself Up','Nicholas Cruze',1,'Used','Fashion','Paperback',20,'Ray','Los Angeles','CA',90009,'Brandon@gmail.com');
Insert into Books values (9781308866875,'Chemistry','John 05er',2,'E-book','Education','Other',34,'Link','Los Angeles','CA',90001,'Jack@gmail.com');
Insert into Books values (9781308866876,'Physics','P.Mani',1,'New','Education','Hardcover',96.50,'05er','Philadelphia','PA',19019,'Mason@gmail.com');
Insert into Books values (9781308866877,'Discrete Mathematics','Ramanu01',3,'E-book','Education','Other',23,'Kily','Los Angeles','CA',90001,'Brandon@gmail.com');
Insert into Books values (9781308866878,'Life Science','Pinto Bell',4,'Used','Education','Hardcover',35,'Raint','Chicago','IL',60051,'Maxwell@gmail.com');
Insert into Books values (9781308866879,'Biology','Sean Michael',6,'E-book','Education','Other',57,'Mith','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9781308866880,'Great Exercise for Great Life','Bond',7,'E-book','Lifestyle','Other',36,'Cooper','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9781308866881,'Yoga Practices','Isha',7,'Used','Lifestyle','Paperback',12.99,'onete','Dallas','TX',75019,'Jayden@gmail.com');
Insert into Books values (9781308866882,'Keep your Body Fit','Lisa,07ia',8,'E-book','Lifestyle','Other',33.50,'pin','Houston','TX',77001,'Jake@gmail.com');
Insert into Books values (9781308866883,'Fitness','James',9,'New','Lifestyle','Paperback',87.50,'James','Miami','FL',33102,'mase@gmail.com');
Insert into Books values (9781308866884,'Impact of Lifestyle','Adam Levine',5,'E-book','Lifestyle','Other',29.99,'UTD','Dallas','TX',75019,'Jayden@gmail.com');

Insert into Books values (9780199679416,'The Book: A Global History','Michael Suarez',1,'E-book','History','Other',45,'ivery','Olympia','WA',98502,'Jill@gmail.com');
Insert into Books values (9780199679417,'Understanding Social Networks','Charles',5,'E-book','Computer','Other',65,'Jay','Los Angeles','CA',90001,'Jack@gmail.com')
Insert into Books values (9780199679418,'Ethics-Introduction','Simon Blackburn',2,'New','Professional','Paperback',94,'Chinatown','San Francisco','CA',94109,'Brandon@gmail.com');
Insert into Books values (9780199679419,'Renewable Energy','Godfrey Boyle',3,'E-book','Environmnet','Other',29,'hons','Knoxville','TN',37087,'Robert@gmail.com');
Insert into Books values (9780199679420,'Celtic Mythology','Philip Freeman',7,'New','History','Hardcover',76,'grin','Philadelphia','PA',19019,'Mason@gmail.com');
Insert into Books values (9780199679421,'The Quran','Abdul Hadeem',9,'Used','Religion','Paperback',22,'Birng','Austin','TX',78702,'Jake@gmail.com');
Insert into Books values (9780199679422,'Atlas','Oxford',6,'New','Geography','Hardcover',10,'Anarchy','Austin','TX',78702,'Jake@gmail.com');
Insert into Books values (9780199679423,'Crime and Criminology','Sue',4,'E-book','Law','Other',54,'Shane','Chicago','IL',60615,'Maxwell@gmail.com');
Insert into Books values (9780199679424,'Cybersecurity and Cyber War','Singer',3,'E-book','Art','Other',37,'Collins','San Francisco','CA',94105,'Brandon@gmail.com');
Insert into Books values (9780199679425,'Oxford American Dictionary','Oxford',2,'New','English','Paperback',10,'Coll','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9780199679426,'Quantum Physics','Michael',1,'E-book','Physics','Other',34,'Angle','Austin','TX',78702,'Jake@gmail.com');
Insert into Books values (9780199679427,'American Poetry','David Lehman',1,'Used','Art','Hardcover',12,'Lever','New York','NY',10032,'Mason@gmail.com');
Insert into Books values (9780199679428,'English Grammar','Oxford Press',5,'New','English','Hardcover',78,'Hind','Atlanta','GA',30305,'Robert@gmail.com');
Insert into Books values (9780199679429,'Pocket Dictionary-English','Oxford',9,'Used','English','Paperback',15,'UTA blvd','arlington','TX',76020,'Jayden@gmail.com');
Insert into Books values (9780199679430,'Concise English Dictionary','Oxford',11,'E-book','English','Other',25,'tist','Houston','TX',77002,'Jayden@gmail.com');


Insert into Books values (9780314697318,'Texas Penal Code','Thomson Reuters',7,'New','Law','Hardcover',48,'trin','Chicago','IL',60056,'Maxwell@gmail.com');
Insert into Books values (9780314697319,'California Probate Code','Thomson Reuters',9,'New','Law','Hardcover',98,'Jerry','San Francisco','CA',94106,'Brandon@gmail.com');
Insert into Books values (9780314697320,'Employment Discrimination Law and Litigation','Pedley',5,'New','Law','Hardcover',350,'E.border','arlington','TX',76010,'Jayden@gmail.com');
Insert into Books values (9780314697321,'Bankruptcy Court 12isions','Thomson Reuters',6,'New','Law','Hardcover',208,'Raymond','San Francisco','CA',94016,'Brandon@gmail.com');

Insert into Books values (9780895779779,'L08hter the best medicine','Readers Digest',5,'New','Entertainment','Hardcover',11.48,'werst','Chicago','IL',60010,'Maxwell@gmail.com');
Insert into Books values (9780895779780,'Selecciones','Sunset Strings',1,'E-book','Magazine','Other',1.67,'Corner','San Francisco','CA',94106,'Jack@gmail.com');
Insert into Books values (9780895779781,'Birds and Blooms','Readers Digest',1,'E-book','Magazine','Other',25,'Rame Blvd','Boston','MA',02110,'Mason@gmail.com');
Insert into Books values (9780895779782,'Life reports','David brooks',1,'E-book','Magazine','Other',25,'Chaples','New York','NY',10009,'Mason@gmail.com');


Insert into Books values (9780205893637,'His Convict Wife','Lena Dowling',3,'E-book','Art','Other',5,'yerk','Philadelphia','PA',19010,'Mason@gmail.com');
Insert into Books values (9780205893638,'The Hideaway','Lauren',1,'New','Stories','Paperback',11.49,'gink','Atlanta','GA',30301,'Robert@gmail.com');
Insert into Books values (9780205893639,'The Problem of Pain','Lewis',2,'Used','Life','Paperback',3.99,'Central Perk','New York','NY',10011,'Mason@gmail.com');
Insert into Books values (9780205893640,'The Travelers Gift','Andy Andrews',3,'New','Stories','Hardcover',12.99,'Lamer','Nashville','TN',37011,'Robert@gmail.com');
Insert into Books values (9780205893641,'Charlottes Web','Gareth Williams',2,'E-book','Stories','',11,'Sideway','Chicago','IL',60626,'Maxwell@gmail.com');
Insert into Books values (9780205893642,'A Classic Christmas','Harper Collins',5,'E-book','Stories','Other',21,'East Blvd','Chicago','IL',60611,'Maxwell@gmail.com');
Insert into Books values (9780205893643,'The Graveyard Book','Neil Gaiman',5,'New','Life','hardcover',10,'gean','Chicago','IL',60040,'Maxwell@gmail.com');


-----------------------------------------------------------------------------------------------------------------
Warehouse Table:-

Insert into Warehouse values (1000,20000,'Austin(TX)');
Insert into Warehouse values (1001,35000,'Los Angeles(CA)');
Insert into Warehouse values (1002,55000,'New York(NY)');
Insert into Warehouse values (1003,30000,'Knoxville(TN)');
Insert into Warehouse values (1004,35000,'Illinois(IL)');
Insert into Warehouse values (1005,25000,'Boulder(CO)');
-------------------------------------------------------------------------------------------------------------------
Seller Table:-

Insert into Seller values (2000,'Great Books',450506349,9724147979,'E.Collins','Dallas','Texas',75098);
Insert into Seller values (2001,'05ers',411328190,4231894653,'Shane','Knoxville','Tennessee',37901);
Insert into Seller values (2002,'Books Online',546981234,4158426975,'Golden','San Francisco','California',94016);
Insert into Seller values (2003,'Powells',325678881,8724676453,'Urban','Champaign','Illinois',61820);
Insert into Seller values (2004,'New Books',544796210,6462361894,'Times','New York','New York',10001);
Insert into Seller values (2005,'William',409176490,4231894653,'Mike','Nashville','Tennessee',37221);
Insert into Seller values (2006,'Barnes&noble',320104681,8729436532,'Maple','Chicago','Illinois',60007);
Insert into Seller values (2007,'Jenkins',571458290,6467926551,'Railway','Rochester','New York',10004);
Insert into Seller values (2008,'Biblio',521097256,7206497753,'Big','Boulder','Colorado',80301);
Insert into Seller values (2009,'LAbooks',570347397,3106838705,'Napier','Los Angeles','California',90005);
Insert into Seller values (2010,'Alibris',523613588,3034678653,'University','Denver','Colorado',80014);
Insert into Seller values (2011,'CloudNine',451986537,5124895309,'Westway','Austin','Texas',78708);

---------------------------------------------------------------------------------------------------------------------
Publisher Table:-

Insert into Publisher values(1200,'Pearson','E.Collins','Dallas','Texas',75096);
Insert into Publisher values(1201,'McGraw-Hill Education','Trans','New York','New York',10008);
Insert into Publisher values(1202,'Wiley','North','Los Angeles','California',90001);
Insert into Publisher values(1203,'Oxford University Press','Gent','San Francisco','California',94016);
Insert into Publisher values(1204,'Thomson Reuters','Lake','Los Angeles','California',90017);
Insert into Publisher values(1205,'Readers Digest','Night','Knoxville','Tennessee',37905);
Insert into Publisher values(1206,'Harper Collins','Sean','Chicago','Illinois',60008);

----------------------------------------------------------------------------------------------------------------------

Customer_Card_Details Table:-

Insert into Customer_Card_Details values('david@gmail.com',4672892780234510,107,'VISA','David Beckham','2020-08-01');
Insert into Customer_Card_Details values ('elisa@gmail.com',4663853865386312,108,'VISA','Elisa Ray','2025-05-01');
Insert into Customer_Card_Details values ('brian@gmail.com',4726575310987613,109,'Mastercard','Brian Mike','2025-12-01');
Insert into Customer_Card_Details values ('tom@gmail.com' ,4726575310987614,110,'Mastercard','Tom Cruise','2025-12-01');
Insert into Customer_Card_Details values ('mike@gmail.com',4726575310987615,111,'VISA','Mike Jack','2020-11-01');
Insert into Customer_Card_Details values ('andy@gmail.com',4726575310987616,112,'Mastercard','Andy Murray','2020-12-01');
Insert into Customer_Card_Details values ('chris@gmail.com',4726575310987617,113,'Mastercard','Chris Nolan','2025-08-01');
Insert into Customer_Card_Details values ('ben@gmail.com', 4726575310987618,114,'Mastercard','Ben Ten','2025-12-01');
Insert into Customer_Card_Details values ('tuyen@gmail.com',4726575310987619,115,'VISA','Tuyen Lisa','2025-05-01');
Insert into Customer_Card_Details values ('nathan@gmail.com',4726575310987620,116,'Mastercard','Nathan Bryan','2025-12-01');
Insert into Customer_Card_Details values ('kelly@gmail.com',4726575310987621,117,'Mastercard','Kelly Ann','2025-05-01');
Insert into Customer_Card_Details values ('ricky@gmail.com',4726575310987622,118,'VISA','Ricky 03tin','2022-01-01');
Insert into Customer_Card_Details values ('neil@gmail.com',4726575310987623,119,'Mastercard','Neil Nithin','2023-04-01');
Insert into Customer_Card_Details values ('karen@gmail.com',4726575310987624,120,'Mastercard','Karen Fisher','2020-08-01');
Insert into Customer_Card_Details values ('paula@gmail.com',4726575310987625,121,'VISA','Paula 07y','2022-01-01');
Insert into Customer_Card_Details values ('cindy@gmail.com',4726575310987626,122,'Mastercard','Cindy Minx','2020-12-01');
Insert into Customer_Card_Details values ('carl@gmail.com',4726575310987627,123,'Mastercard','Carl 03x','2023-04-01');
Insert into Customer_Card_Details values ('johnson12@gmail.com',4726575310987628,124,'VISA','Johnson Michael','2025-05-01');
Insert into Customer_Card_Details values ('michael1@gmail.com',4726575310987629,125,'Mastercard','Michael Shawn','2022-01-01');
Insert into Customer_Card_Details values ('selena5@gmail.com',4726575310987630,126,'Mastercard','Selena Gomez','2025-12-01');
Insert into Customer_Card_Details values ('peter8@gmail.com',4726575310987631,127,'VISA','Peter Pan','2023-04-01');
Insert into Customer_Card_Details values ('pat@gmail.com',4726575310987632,128,'Mastercard','Patrick John','2022-01-01');
Insert into Customer_Card_Details values ('don@gmail.com',4726575310987633,129,'Mastercard','Donald Jones','2020-12-01');
Insert into Customer_Card_Details values ('james@gmail.com',4726575310987634,130,'VISA','James Anderson','2025-05-01');
Insert into Customer_Card_Details values ('alisha@gmail.com',4726575310987635,131,'Mastercard','Alisha Michelle','2025-12-01');
Insert into Customer_Card_Details values ('emily@gmail.com',4726575310987636,132,'Mastercard','Emily Clark','2023-04-01');
Insert into Customer_Card_Details values ('aaliyah@gmail.com',4726575310987637,133,'VISA','Aaliyah Bhatt','2020-08-01');
Insert into Customer_Card_Details values ('jennifer@gmail.com',4726575310987638,134,'Mastercard','Jennifer Aniston','2025-12-01');
Insert into Customer_Card_Details values ('olivia@gmail.com',4726575310987639,135,'Mastercard','Olivia Austin','2022-01-01');
Insert into Customer_Card_Details values ('hannah@gmail.com',4726575310987640,136,'VISA','Hannah Montana','2020-08-01');
Insert into Customer_Card_Details values ('jessica@gmail.com',4726575310987641,137,'Mastercard','Jessica James','2023-04-01');
Insert into Customer_Card_Details values ('sarah@gmail.com', 4726575310987642,138,'Mastercard','Sarah 05','2025-12-01');
Insert into Customer_Card_Details values ('lily@gmail.com', 4726575310987643,139,'Mastercard','Lily 07ie','2022-01-01');
Insert into Customer_Card_Details values ('savannah@gmail.com',4726575310987644,140,'VISA','Savannah Stone','2025-12-01');
Insert into Customer_Card_Details values ('isabella@gmail.com',4726575310987645,141,'Mastercard','Isabella 03y','2025-12-01');
Insert into Customer_Card_Details values ('sophia@gmail.com',4726575310987646,142,'VISA','Sophia Bary','2020-08-01');
Insert into Customer_Card_Details values ('ava@gmail.com',4726575310987647,143,'Mastercard','Ava Adam','2025-12-01');
Insert into Customer_Card_Details values ('grace@gmail.com',4726575310987648,144,'Mastercard','Grace Annie','2023-04-01');
Insert into Customer_Card_Details values ('Mia@gmail.com',4726575310987649,145,'VISA','Mia Doll','2023-04-01');
Insert into Customer_Card_Details values ('Ella@gmail.com',4726575310987650,146,'Mastercard','Ella Rose','2025-05-01');
Insert into Customer_Card_Details values ('alyssa@gmail.com',4726575310987651,147,'Mastercard','Alyssa Rose','2022-01-01');
Insert into Customer_Card_Details values ('lucy@gmail.com',4726575310987652,148,'VISA','Lucy Pinder','2025-12-01');
Insert into Customer_Card_Details values ('jade@gmail.com',4726575310987653,149,'Mastercard','Jade Steven','2025-05-01');
Insert into Customer_Card_Details values ('abby@gmail.com',4726575310987654,150,'Mastercard','Abby Brrok','2025-12-01');
Insert into Customer_Card_Details values ('kellie@gmail.com',4726575310987655,151,'VISA','Kellie Watson','2025-05-01' );
Insert into Customer_Card_Details values ('natalie@gmail.com',4726575310987656,152,'Mastercard','Natalie Gulbis','2025-12-01');
Insert into Customer_Card_Details values ('amanda@gmail.com', 4726575310987657,153,'Mastercard','Amanda Mills','2020-12-01');
Insert into Customer_Card_Details values ('bella@gmail.com',4726575310987658,154,'VISA','Bella Reese','2025-12-01');
Insert into Customer_Card_Details values ('rachel@gmail.com',4726575310987658,155,'Mastercard','Rachael Green','2023-04-01');
Insert into Customer_Card_Details values ('taylor@gmail.com',4726575310987660,156,'Mastercard','Taylor Swift','2025-05-01');
Insert into Customer_Card_Details values ('alexis@gmail.com',4726575310987661,157,'VISA','Alexis Ford','2025-12-01');
Insert into Customer_Card_Details values ('paige@gmail.com',4726575310987662,158,'Mastercard','Paige Rose','2020-12-01');
Insert into Customer_Card_Details values ('jacob@gmail.com',4726575310987663,159,'VISA','Jacob John','2025-12-01');
Insert into Customer_Card_Details values ('Shawn@gmail.com',4726575310987664,160,'Mastercard','Shawn Shape','2025-12-01');
Insert into Customer_Card_Details values ('Muhammad@gmail.com',4726575310987665,161,'Mastercard','Muhammas Nazar','2025-05-01');
Insert into Customer_Card_Details values ('Aaron@gmail.com',4726575310987666,162,'VISA','Aaron Finch','2020-12-01');
Insert into Customer_Card_Details values ('Daniel@gmail.com', 4726575310987667,163,'VISA','Daniel Robin','2022-01-01');
Insert into Customer_Card_Details values ('Alex@gmail.com',4726575310987668,164,'Mastercard','Alex John','2023-04-01');
Insert into Customer_Card_Details values ('Jonah@gmail.com', 4726575310987669,165,'Mastercard','Jonah Bren','2025-12-01');
Insert into Customer_Card_Details values ('Michael@gmail.com',4726575310987670,166,'VISA','Michael Shen','2022-01-01');
Insert into Customer_Card_Details values ('James@gmail.com',4726575310987671,167,'Mastercard','James Chris','2025-12-01');
Insert into Customer_Card_Details values ('Ryan@gmail.com',4726575310987672,168,'VISA','Ryan Reynold','2025-12-01');
Insert into Customer_Card_Details values ('Liam@gmail.com',4726575310987673,169,'Mastercard','Liam Neeson','2022-01-01');
Insert into Customer_Card_Details values ('David@gmail.com',4726575310987674,170,'Mastercard','David Levin','2025-12-01');
Insert into Customer_Card_Details values ('Mathew@gmail.com',4726575310987675,171,'VISA','Mathew Hayden','2020-12-01');
Insert into Customer_Card_Details values ('Jack@gmail.com',4726575310987676,172,'Mastercard','Jack Sock','2022-01-01');
Insert into Customer_Card_Details values ('Ethan@gmail.com',4726575310987677,173,'Mastercard','Ethan Hunt','2023-04-01');
Insert into Customer_Card_Details values ('Luke@gmail.com',4726575310987678,174,'VISA','Luke Wang','2020-08-01');
Insert into Customer_Card_Details values ('Jordan@gmail.com',4726575310987679,175,'Mastercard','Jordan Mike','2025-12-01');
Insert into Customer_Card_Details values ('Harry@gmail.com', 4726575310987680,176,'Mastercard','Harry Lane','2025-12-01');
Insert into Customer_Card_Details values ('Alexander@gmail.com',4726575310987681,177,'VISA','Alexander Bell','2022-01-01');
Insert into Customer_Card_Details values ('Ali@gmail.com',4726575310987682,178,'Mastercard','Ali Sharif','2025-05-01');
Insert into Customer_Card_Details values ('Tyler@gmail.com',4726575310987683,179,'VISA','Tyler 03n','2022-01-01');
Insert into Customer_Card_Details values ('Kevin@gmail.com',4726575310987684,180,'Mastercard','Kevin Peter','2023-04-01');
Insert into Customer_Card_Details values ('Joshua@gmail.com',4726575310987685,181,'Mastercard','Joshua Adam','2020-08-01');
Insert into Customer_Card_Details values ('Dylan@gmail.com',4726575310987686,182,'VISA','Dylan Rider','2025-12-01');
Insert into Customer_Card_Details values ('Blake@gmail.com',4726575310987687,183,'Mastercard','Blake John','2023-04-01');
Insert into Customer_Card_Details values ('Andrew@gmail.com',4726575310987688,184,'VISA','Andrew Tye','2025-05-01');
Insert into Customer_Card_Details values ('Zayn@gmail.com',4726575310987689,185,'Mastercard','Zayn David','2025-12-01');
Insert into Customer_Card_Details values ('Christopher@gmail.com',4726575310987690,186,'VISA','Christopher Night','2020-08-01');
Insert into Customer_Card_Details values ('Johnnn@gmail.com',4726575310987691,187,'Mastercard','John Leger','2025-12-01');
Insert into Customer_Card_Details values ('Adam@gmail.com',4726575310987692,188,'Mastercard','Adam Levine','2025-05-01');
Insert into Customer_Card_Details values ('Noah@gmail.com',4726575310987693,189,'VISA','Noah Bill','2025-12-01');
Insert into Customer_Card_Details values ('William@gmail.com',4726575310987694,190,'Mastercard','William Mason','2020-12-01');
Insert into Customer_Card_Details values ('Aiden@gmail.com',4726575310987695,191,'VISA','Aiden Mills','2025-12-01');
Insert into Customer_Card_Details values ('Spencer@gmail.com',4726575310987696,192,'Mastercard','Spencer Shawn','2025-12-01');
Insert into Customer_Card_Details values ('Nathan@gmail.com',4726575310987697,193,'Mastercard','Nathan Lyon','2020-12-01');
Insert into Customer_Card_Details values ('Niall@gmail.com', 4726575310987698,194,'VISA','Niall Horan','2020-08-01');
Insert into Customer_Card_Details values ('Logan@gmail.com',4726575310987699,195,'Mastercard','Logan Hulk','2023-04-01');
Insert into Customer_Card_Details values ('Jason@gmail.com',4726575310987701,196,'VISA','Jason 05er','2020-12-01');
Insert into Customer_Card_Details values ('Robert@gmail.com',4726575310987702,197,'Mastercard','Robert 06ior','2025-12-01');
Insert into Customer_Card_Details values ('Austin@gmail.com',4726575310987703,198,'VISA','Austin 05','2020-12-01');
Insert into Customer_Card_Details values ('Anthony@gmail.com',4726575310987704,199,'Mastercard','Anthony Jo09h','2025-05-01');
Insert into Customer_Card_Details values ('Louis@gmail.com', 4726575310987705,200,'VISA','Louis Phil','2023-04-01');
Insert into Customer_Card_Details values ('Jayden@gmail.com',4726575310987706,201,'Mastercard','Jayden Mike','2025-12-01');
Insert into Customer_Card_Details values ('Brian@gmail.com',4726575310987707,202,'VISA','Brian James','2020-08-01');
Insert into Customer_Card_Details values ('Mason@gmail.com', 4726575310987708,203,'Mastercard','Mason Jake','2025-12-01');
Insert into Customer_Card_Details values ('Kyle@gmail.com', 4726575310987709,204,'VISA','Kyle Sean','2020-08-01');
Insert into Customer_Card_Details values ('Max@gmail.com',4726575310987710,205,'Mastercard','Max Glenn','2023-04-01');
Insert into Customer_Card_Details values ('Brandon@gmail.com',4726575310987711,206,'VISA','Brandon Gates','2025-05-01');
----------------------------------------------------------------------------------------------------------------------------
Buys Table:-

Insert into Buys values('michael1@gmail.com',9780132319669,'2016-11-03',7,1,63.13);
Insert into Buys values ('sarah@gmail.com',9781119404589,'2016-12-05',10.25,1,27.56);
Insert into Buys values ('Jack@gmail.com',9781308866872,'2016-11-08',7.50,1,93.52);
Insert into Buys values ('emily@gmail.com' ,9780205893637,'2017-01-14',8,1,5.4);
Insert into Buys values ('Noah@gmail.com',9780199679420,'2017-02-15',8,1,82.08);
Insert into Buys values ('michael1@gmail.com',9780132319669,'2016-06-16',7,1,63.13);
Insert into Buys values ('Max@gmail.com',9780314697318,'2016-07-05',10.25,1,52.92);
Insert into Buys values ('Nathan@gmail.com',9780199679424,'2016-03-11',8.5,1,40.15);
Insert into Buys values ('jennifer@gmail.com',9780205893639,'2016-10-05',8.875,2,4.34);
Insert into Buys values ('Austin@gmail.com',9781119404592,'2016-02-12',6.25,1,95.61);
Insert into Buys values ('Anthony@gmail.com',9781308866861,'2016-02-12',6.25,29);
Insert into Buys values('ricky@gmail.com',9781447928911,'2016-11-06',7.50,23);
Insert into Buys values('Spencer@gmail.com',9781405865234,'2016-07-12',7,6.4);
Insert into Buys values('Spencer@gmail.com',9781405865852,'2017-01-11',7,52);
Insert into Buys values('ricky@gmail.com',9781405865234,'2016-11-12',7.50,52);
Insert into Buys values('Nathan@gmail.com',9780205892723,'2016-03-02-',8,27.99);
Insert into Buys values('johnson12@gmail.com',9780130971401,'2016-10-03-',7.50,72.99);
Insert into Buys values('taylor@gmail.com',9780134109879,'2017-11-05-',8,13.99);
Insert into Buys values('grace@gmail.com',9780321911216,'2016-09-02',8.5,21.99);
Insert into Buys values('andy@gmail.com',9780134093413,'2017-05-11-',7,35.99);
Insert into Buys values('chris@gmail.com',9780321701763,'2016-12-12-',6.25,14);
Insert into Buys values('ben@gmail.com',9780321701770,'2017-02-27',7,34);
Insert into Buys values('tuyen@gmail.com',9780133073003,'2016-11-02',8,23.99);
Insert into Buys values('peter8@gmail.com',9780134128689,'2016-12-04',8,128.99);
Insert into Buys values('jade@gmail.com',9780139569968,'2016-06-06',7.50,104);
Insert into Buys values('james@gmail.com',9780205892783,'2017-08-07',7,89);
Insert into Buys values('olivia@gmail.com',9780131594753,'2016-10-08',6.5,32.99);
Insert into Buys values('johnson12@gmail.com',9780321333056,'2016-06-04',7.50,59);
Insert into Buys values('tuyen@gmail.com',9780321394262,'2017-02-22-',8,36.50);
Insert into Buys values('taylor@gmail.com',9780131405677,'2016-09-09',8,27);
Insert into Buys values('grace@gmail.com',9780134143316,'2016-02-02',8.5,72.99);
Insert into Buys values('tuyen@gmail.com',9780321701763,'2017-07-02',8,25.14);
Insert into Buys values('bella@gmail.com',9780130915689,'2017-07-03',6,35.99);
Insert into Buys values('rachel@gmail.com',9780133036091,'2017-07-06',10,149.99);
Insert into Buys values('taylor@gmail.com',9780672336232,'2017-05-13',7,45);
Insert into Buys values('alexis@gmail.com',9780205892743,'2017-05-04',7,57);
Insert into Buys values('paige@gmail.com',9780205892863,'2017-07-04',8,95  );
Insert into Buys values('jacob@gmail.com',9781119404583,'2017-02-05',7,65);
Insert into Buys values('Shawn@gmail.com',9781119404584,'2017-12-05',6,26.99);
Insert into Buys values('Muhammad@gmail.com',9781119404585,'2017-03-06',6,27.99);
Insert into Buys values('Aaron@gmail.com',9781119404586,'2017-12-06',7,89);
Insert into Buys values('Daniel@gmail.com',9781119404587,'2017-04-07',5,25.49);
Insert into Buys values('Alex@gmail.com',9781119404588,'2017-05-07',6,24);
Insert into Buys values('Jonah@gmail.com',9781119404589,'2017-05-08',6,25);
Insert into Buys values('Michael@gmail.com',9781119404590 ,'2017-10-08',7,59.99);
Insert into Buys values('James@gmail.com',9781119404591,'2017-08-08',6,22);
Insert into Buys values('Ryan@gmail.com',9781119404592,'2017-06-09',7,89.99);
Insert into Buys values('Liam@gmail.com',9781119404593 ,'2017-07-09',6,20);
Insert into Buys values('David@gmail.com',9781119404594,'2017-07-10',6,11);
Insert into Buys values('Mathew@gmail.com',9781119404595,'2017-09-10',6,25);
Insert into Buys values('Jack@gmail.com',9781119404596,'2017-11-02',6,12);
Insert into Buys values('Ethan@gmail.com',9781119404597,'2017-11-10',6,23.40);

------------------------------------------------------------------------------------------------------------------------------
Publishes Table:-

Insert into Publishes values(1200,9780132319669);
Insert into Publishes values (1202,9781119404589);
Insert into Publishes values (1201,9781308866872);
Insert into Publishes values (1206,9780205893637);
Insert into Publishes values (1203,9780199679420);
Insert into Publishes values (1204,9780314697318);
Insert into Publishes values (1203,9780199679424);
Insert into Publishes values (1206,9780205893639);
Insert into Publishes values (1202,9781119404592);
--------------------------------------------------------------------------------------------------------------------------------

Sells Table:-

Insert into Sells values(2001,9780132319669,50);
Insert into Sells values (2010,9781119404589,19);
Insert into Sells values (2000,9781308866872,75);
Insert into Sells values (2006,9780205893637,3);
Insert into Sells values (2003,9780199679420,66);
Insert into Sells values (2001,9780132319669,50);
Insert into Sells values (2004,9780314697318,39);
Insert into Sells values (2000,9780199679424,32);
Insert into Sells values (2006,9780205893639,2.5);
Insert into Sells values (2009,9781119404592,80);
----------------------------------------------------------------------------------------------------------------------------------
Stocks Table:-

Insert into Stocks values(1001,9780132319669);
Insert into Stocks values (1004,9781119404589);
Insert into Stocks values (1000,9781308866872);
Insert into Stocks values (1005,9780205893637);
Insert into Stocks values (1003,9780199679420);
Insert into Stocks values (1004,9780314697318);
Insert into Stocks values (1000,9780199679424);
Insert into Stocks values (1002,9780205893639);
Insert into Stocks values (1005,9781119404592);
Insert into Stocks values (1003,9780132319669);
Insert into Stocks values (1005,9780132319669);
