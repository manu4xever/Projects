-----------------Script to drop all the tables(11 tables)------------------
DROP TABLE Customer;
DROP TABLE Employee;
DROP TABLE Publisher; 
DROP TABLE Books; 
DROP TABLE Seller; 
DROP TABLE Warehouse;
DROP TABLE Customer_Card_Details; 
DROP TABLE Buys;
DROP TABLE Sells;
DROP TABLE Stocks;
DROP TABLE Publishes;