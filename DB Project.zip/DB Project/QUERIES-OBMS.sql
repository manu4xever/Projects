-----------------------------1.Which genre of books has been purchased more by the Customers?-------------------------
select * from  (
Select COUNT(Genre) as Tot,Genre 
            From Books 
            Group by Genre
            Order By Tot desc) 
            where Tot = (
            select max(Tot) from  (
                    Select COUNT(Genre) as Tot,Genre 
                    From Books 
                    Group by Genre
                    Order By Tot desc));
                    
--------------------------------------2.Which type of Book is more preferred?-------------------------------------------
select * from  (
Select COUNT(Type) as Total,Type 
            From Books 
            Group by Type
            Order By Total desc) 
            where Total = (
            select max(Total) from  (
                    Select COUNT(Type) as Total,Type 
                    From Books 
                    Group by Type
                    Order By Total desc));
                    
----------------------------------------3.Which Type of Binding is preferred the most?--------------------------------
select * from  (
Select COUNT(Binding_Type) as T,Binding_Type 
            From Books 
            Group by Binding_Type
            Order By T desc) 
            where T = (
            select max(T) from  (
                    Select COUNT(Binding_Type) as T,Binding_Type 
                    From Books 
                    Group by Binding_Type
                    Order By T desc));
                    
-------------------------------------4.Which Customer has bought more number of books?-------------------------------
Select * From(Select Count(ISBN) as U,User_ID, First_Name, Last_Name
                    From Buys NATURAL JOIN Customer
                    Group By User_ID,First_Name, Last_Name
                    Order By U desc) 
            where U = (
            select MAX(U) as MAXVAL from  (Select COUNT(ISBN) as U,User_ID
                                 From Buys 
                                 Group by User_ID
                                 Order By U desc));
                                 
---------------------------------------5.Identify the most preferred publication for a genre-----------------------------
Select Publisher_Name
From (Select COUNT(ISBN) as M,Publisher_Name
                  From ((Buys Inner join Books on Buys.ISBN=Books.ISBN ) INNER JOIN Publishes on Buys.ISBN=Publishes.ISBN)Inner JOIN Publisher on Publishes.Publisher_ID=Publisher.Publisher_ID
                  Where Genre='Art'
                  Group by Publisher_Name)
where M = (select MAX(M) 
           From  (Select COUNT(ISBN) as M,Publisher_Name
                  From ((Buys Inner join Books on Buys.ISBN=Books.ISBN ) INNER JOIN Publishes on Buys.ISBN=Publishes.ISBN)Inner JOIN Publisher on Publishes.Publisher_ID=Publisher.Publisher_ID
                  Where Genre='Art'
                  Group by Publisher_Name
                  ));
--------------------------------------6.Which State spends more money on books?----------------------------------------------
Select State
FROM (Select SUM(Price) as Total_Money,State
      From Buys JOIN Books on Buys.User_ID=Books.User_ID
      Group by State
      Order by Total_Money desc)
where Total_Money = (Select MAX(Total_Money)
                     From (Select SUM(Price) as Total_Money,State
                           From Buys JOIN Books on Buys.User_ID=Books.User_ID
                           Group by State
                           Order by Total_Money desc));
 
--------------------------------------7.Find the Employee with Highest Salary-----------------------------------------
Select First_Name, Last_Name
From Employee
Where Salary= (Select MAX(Salary) as Sal
               From Employee);
               
---------------------------------8.Identify the Employee who ships more books From Warehouse 1001---------------------
Select First_Name,Last_Name
From Employee
where User_ID =(Select User_ID
                From (Select Count(ISBN) as TotalISBN,User_ID
                From Employee Natural Join Books
                Where Warehouse_ID=1001 AND Designation='Warehouse Worker'
                Group By User_ID
                Order by TotalISBN desc));
---------------------------------9.Which Zipcode Buys Books from a particular Genre(say Art)?---------------------
select ZIP from Books,Buys
where Books.ISBN = Buys.ISBN AND Genre='Art';